'use client'

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  type Dispatch,
  type ReactNode,
} from 'react'
import {
  ACTION_DURATION_MS,
  CAT_DURATION_MS,
  DEFAULT_CONFIG,
  MAX_PROFILES,
  SHAPESHIFT_INTERVAL_MS,
  type ActionKind,
  type Alignment,
  type AvatarConfig,
  type CameraMode,
  type CreatureKind,
  type Form,
  type Profile,
} from '@/lib/devil-config'

export interface DevilState {
  profiles: Profile[]
  activeId: string
  camera: CameraMode
  form: Form
  creature: CreatureKind | null
  activeNumber: string | null
  smokeKey: number
  action: { kind: ActionKind; key: number } | null
  chakras: Record<string, number>
  nextShiftAt: number
  catUntil: number | null
  notice: { text: string; key: number } | null
}

type DevilAction =
  | { type: 'select-profile'; id: string }
  | { type: 'create-profile'; name: string; alignment: Alignment }
  | { type: 'delete-profile'; id: string }
  | { type: 'update-config'; patch: Partial<AvatarConfig> }
  | { type: 'set-alignment'; alignment: Alignment }
  | { type: 'toggle-lock' }
  | { type: 'set-camera'; camera: CameraMode }
  | { type: 'cast-creature'; number: string; creature: CreatureKind }
  | { type: 'cast-action'; number: string; action: ActionKind }
  | { type: 'clear-action'; key: number }
  | { type: 'shift-now' }
  | { type: 'toggle-chakra'; id: string; minutes: number; now: number }
  | { type: 'tick'; now: number }
  | { type: 'clear-notice'; key: number }

const firstProfile: Profile = {
  id: 'profile-1',
  name: 'NIHALLHAMEEDPK',
  alignment: 'devil',
  locked: false,
  config: DEFAULT_CONFIG,
}

const initialState: DevilState = {
  profiles: [firstProfile],
  activeId: firstProfile.id,
  camera: 'body',
  form: 'devil',
  creature: null,
  activeNumber: null,
  smokeKey: 0,
  action: null,
  chakras: {},
  nextShiftAt: 0,
  catUntil: null,
  notice: null,
}

let profileCounter = 1

function notify(state: DevilState, text: string): DevilState['notice'] {
  return { text, key: (state.notice?.key ?? 0) + 1 }
}

function updateActive(state: DevilState, fn: (p: Profile) => Profile): Profile[] {
  return state.profiles.map((p) => (p.id === state.activeId ? fn(p) : p))
}

function reducer(state: DevilState, action: DevilAction): DevilState {
  const active = state.profiles.find((p) => p.id === state.activeId) ?? state.profiles[0]

  switch (action.type) {
    case 'select-profile':
      return { ...state, activeId: action.id }

    case 'create-profile': {
      if (state.profiles.length >= MAX_PROFILES) return state
      profileCounter += 1
      const profile: Profile = {
        id: `profile-${profileCounter}-${state.profiles.length}`,
        name: action.name.trim().toUpperCase().slice(0, 24) || `SIGIL ${state.profiles.length + 1}`,
        alignment: action.alignment,
        locked: false,
        config: {
          ...DEFAULT_CONFIG,
          wings: action.alignment === 'angel' ? 'bone' : DEFAULT_CONFIG.wings,
          eyes: action.alignment === 'angel' ? 'gold' : DEFAULT_CONFIG.eyes,
        },
      }
      return {
        ...state,
        profiles: [...state.profiles, profile],
        activeId: profile.id,
        notice: notify(state, `Profile ${profile.name} summoned`),
      }
    }

    case 'delete-profile': {
      if (state.profiles.length <= 1) return state
      const profiles = state.profiles.filter((p) => p.id !== action.id)
      return {
        ...state,
        profiles,
        activeId: state.activeId === action.id ? profiles[0].id : state.activeId,
      }
    }

    case 'update-config':
      if (active.locked) return state
      return {
        ...state,
        profiles: updateActive(state, (p) => ({ ...p, config: { ...p.config, ...action.patch } })),
      }

    case 'set-alignment':
      if (active.locked) return state
      return { ...state, profiles: updateActive(state, (p) => ({ ...p, alignment: action.alignment })) }

    case 'toggle-lock': {
      const locking = !active.locked
      return {
        ...state,
        profiles: updateActive(state, (p) => ({ ...p, locked: locking })),
        form: locking ? 'devil' : state.form,
        creature: locking ? null : state.creature,
        activeNumber: locking ? null : state.activeNumber,
        catUntil: locking ? null : state.catUntil,
        smokeKey: locking && state.form !== 'devil' ? state.smokeKey + 1 : state.smokeKey,
        notice: notify(state, locking ? `${active.name} bound in hellfire chains` : 'Chains shattered'),
      }
    }

    case 'clear-notice':
      return state.notice?.key === action.key ? { ...state, notice: null } : state

    case 'set-camera':
      return { ...state, camera: action.camera }

    case 'cast-creature': {
      if (active.locked) {
        return { ...state, notice: notify(state, 'Locked profiles cannot shapeshift') }
      }
      const reverting = state.form === 'creature' && state.activeNumber === action.number
      return {
        ...state,
        form: reverting ? 'devil' : 'creature',
        creature: reverting ? null : action.creature,
        activeNumber: reverting ? null : action.number,
        catUntil: null,
        smokeKey: state.smokeKey + 1,
        notice: notify(state, reverting ? 'Smoke reforms the avatar' : `${action.number} · smoke transformation`),
      }
    }

    case 'cast-action': {
      const key = (state.action?.key ?? 0) + 1
      const shouldRevert = state.form !== 'devil'
      return {
        ...state,
        form: 'devil',
        creature: null,
        activeNumber: action.number,
        catUntil: null,
        smokeKey: shouldRevert ? state.smokeKey + 1 : state.smokeKey,
        action: { kind: action.action, key },
      }
    }

    case 'clear-action':
      if (state.action?.key !== action.key) return state
      return {
        ...state,
        action: null,
        activeNumber: state.form === 'devil' ? null : state.activeNumber,
      }

    case 'shift-now':
      if (active.locked) return { ...state, notice: notify(state, 'Locked profiles cannot shapeshift') }
      if (state.form === 'cat') {
        return {
          ...state,
          form: 'devil',
          catUntil: null,
          smokeKey: state.smokeKey + 1,
          nextShiftAt: Date.now() + SHAPESHIFT_INTERVAL_MS,
        }
      }
      return {
        ...state,
        form: 'cat',
        creature: null,
        activeNumber: null,
        catUntil: Date.now() + CAT_DURATION_MS,
        smokeKey: state.smokeKey + 1,
      }

    case 'toggle-chakra': {
      const chakras = { ...state.chakras }
      if (chakras[action.id]) delete chakras[action.id]
      else chakras[action.id] = action.now + action.minutes * 60_000
      return { ...state, chakras }
    }

    case 'tick': {
      const { now } = action
      let next = state

      const expired = Object.entries(state.chakras).filter(([, endsAt]) => endsAt <= now)
      if (expired.length) {
        const chakras = { ...state.chakras }
        for (const [id] of expired) delete chakras[id]
        next = { ...next, chakras }
      }

      if (next.nextShiftAt === 0) return { ...next, nextShiftAt: now + SHAPESHIFT_INTERVAL_MS }

      if (next.form === 'cat' && next.catUntil && now >= next.catUntil) {
        return {
          ...next,
          form: 'devil',
          catUntil: null,
          smokeKey: next.smokeKey + 1,
          nextShiftAt: now + SHAPESHIFT_INTERVAL_MS,
        }
      }

      if (now >= next.nextShiftAt && next.form !== 'cat') {
        if (next.form === 'devil' && !active.locked && !next.action) {
          return {
            ...next,
            form: 'cat',
            catUntil: now + CAT_DURATION_MS,
            smokeKey: next.smokeKey + 1,
            notice: notify(next, 'Shapeshift · the black cat walks'),
          }
        }
        return { ...next, nextShiftAt: now + SHAPESHIFT_INTERVAL_MS }
      }

      return next
    }
  }
}

interface DevilContextValue {
  state: DevilState
  active: Profile
  dispatch: Dispatch<DevilAction>
}

const DevilContext = createContext<DevilContextValue | null>(null)

export function DevilProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  useEffect(() => {
    dispatch({ type: 'tick', now: Date.now() })
    const id = window.setInterval(() => dispatch({ type: 'tick', now: Date.now() }), 1000)
    return () => window.clearInterval(id)
  }, [])

  const actionKey = state.action?.key
  useEffect(() => {
    if (!actionKey) return
    const id = window.setTimeout(() => dispatch({ type: 'clear-action', key: actionKey }), ACTION_DURATION_MS)
    return () => window.clearTimeout(id)
  }, [actionKey])

  const noticeKey = state.notice?.key
  useEffect(() => {
    if (!noticeKey) return
    const id = window.setTimeout(() => dispatch({ type: 'clear-notice', key: noticeKey }), 2800)
    return () => window.clearTimeout(id)
  }, [noticeKey])

  const active = state.profiles.find((p) => p.id === state.activeId) ?? state.profiles[0]
  const value = useMemo(() => ({ state, active, dispatch }), [state, active])

  return <DevilContext.Provider value={value}>{children}</DevilContext.Provider>
}

export function useDevil() {
  const ctx = useContext(DevilContext)
  if (!ctx) throw new Error('useDevil must be used inside DevilProvider')
  return ctx
}
