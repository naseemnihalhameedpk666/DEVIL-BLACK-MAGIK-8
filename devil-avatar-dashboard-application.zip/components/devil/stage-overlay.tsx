'use client'

import { AnimatePresence, motion } from 'framer-motion'
import { Cat, Lock, LockOpen, ScanFace, PersonStanding, Sparkles } from 'lucide-react'
import { CAT_DURATION_MS, CREATURE_LABELS, SHAPESHIFT_INTERVAL_MS } from '@/lib/devil-config'
import { cn } from '@/lib/utils'
import { useDevil } from './devil-store'
import { formatClock, useNow } from './use-now'

export function StageOverlay() {
  const { state, active, dispatch } = useDevil()
  const now = useNow()

  const formLabel =
    state.form === 'cat' ? 'Black Cat' : state.form === 'creature' && state.creature ? CREATURE_LABELS[state.creature] : 'Devil Avatar'

  let countdownLabel = 'Shapeshift in'
  let remaining = 0
  let progress = 0
  if (now && state.form === 'cat' && state.catUntil) {
    countdownLabel = 'Reverting in'
    remaining = state.catUntil - now
    progress = 1 - remaining / CAT_DURATION_MS
  } else if (now && state.nextShiftAt) {
    remaining = state.nextShiftAt - now
    progress = 1 - remaining / SHAPESHIFT_INTERVAL_MS
  }

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="pointer-events-auto rounded-xl border border-border bg-background/60 px-3 py-2 backdrop-blur-md">
          <p className="font-serif text-[10px] tracking-[0.35em] text-gold">INFERNUM</p>
          <h1 className="font-serif text-base font-semibold tracking-wider text-foreground sm:text-lg">{active.name}</h1>
          <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
            <span
              aria-hidden
              className={cn('size-1.5 rounded-full', active.alignment === 'angel' ? 'bg-gold' : 'bg-crimson')}
            />
            {active.alignment === 'angel' ? 'Angel' : 'Devil'} profile · {formLabel}
          </p>
        </div>

        <div
          role="radiogroup"
          aria-label="Camera mode"
          className="pointer-events-auto flex rounded-xl border border-border bg-background/60 p-1 backdrop-blur-md"
        >
          {(
            [
              { id: 'face', label: 'Face Zoom', icon: ScanFace },
              { id: 'body', label: 'Full Body', icon: PersonStanding },
            ] as const
          ).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={state.camera === id}
              onClick={() => dispatch({ type: 'set-camera', camera: id })}
              className={cn(
                'flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors sm:px-3',
                state.camera === id ? 'bg-gold text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              <Icon className="size-3.5" aria-hidden />
              <span className="hidden sm:inline">{label}</span>
              <span className="sm:hidden">{id === 'face' ? 'Face' : 'Body'}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col items-center">
        <AnimatePresence mode="wait">
          {state.notice && (
            <motion.p
              key={state.notice.key}
              initial={{ opacity: 0, y: 8, filter: 'blur(6px)' }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: -8, filter: 'blur(6px)' }}
              transition={{ duration: 0.4 }}
              onAnimationComplete={() => undefined}
              className="rounded-full border border-gold/30 bg-background/70 px-4 py-1.5 font-serif text-xs tracking-widest text-gold backdrop-blur-md"
              role="status"
            >
              {state.notice.text}
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      <div className="flex items-end justify-between gap-3">
        <div className="pointer-events-auto w-48 rounded-xl border border-border bg-background/60 p-3 backdrop-blur-md sm:w-56">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Cat className="size-3.5 text-gold" aria-hidden />
              {active.locked ? 'Shapeshift sealed' : countdownLabel}
            </span>
            <span className="font-mono tabular-nums text-foreground">
              {active.locked || !now || !state.nextShiftAt ? '--:--' : formatClock(remaining)}
            </span>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-muted" aria-hidden>
            <div
              className="h-full rounded-full bg-gradient-to-r from-crimson to-gold transition-[width] duration-1000 ease-linear"
              style={{ width: `${active.locked ? 0 : Math.min(100, Math.max(0, progress * 100))}%` }}
            />
          </div>
          <button
            type="button"
            disabled={active.locked}
            onClick={() => dispatch({ type: 'shift-now' })}
            className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg border border-border py-1.5 text-xs text-foreground transition-colors hover:border-gold/60 hover:text-gold disabled:opacity-40"
          >
            <Sparkles className="size-3.5" aria-hidden />
            {state.form === 'cat' ? 'Revert now' : 'Shapeshift now'}
          </button>
        </div>

        <button
          type="button"
          onClick={() => dispatch({ type: 'toggle-lock' })}
          aria-pressed={active.locked}
          className={cn(
            'pointer-events-auto flex items-center gap-2 rounded-xl border px-4 py-3 font-serif text-sm font-semibold tracking-widest backdrop-blur-md transition-all',
            active.locked
              ? 'border-gold/60 bg-gold/15 text-gold shadow-[0_0_30px_-6px] shadow-gold/60 hover:bg-gold/25'
              : 'border-crimson/60 bg-crimson/15 text-foreground shadow-[0_0_30px_-6px] shadow-crimson/70 hover:bg-crimson/25',
          )}
        >
          {active.locked ? <LockOpen className="size-4" aria-hidden /> : <Lock className="size-4" aria-hidden />}
          {active.locked ? 'UNLOCK' : 'LOCK'}
        </button>
      </div>
    </div>
  )
}
