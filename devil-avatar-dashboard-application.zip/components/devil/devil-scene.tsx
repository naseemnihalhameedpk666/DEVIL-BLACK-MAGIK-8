'use client'

import { useCallback, useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, Sparkles, Stars } from '@react-three/drei'
import { Bloom, EffectComposer, Vignette } from '@react-three/postprocessing'
import * as THREE from 'three'
import { BUILD_SCALE, type CameraMode, type Form } from '@/lib/devil-config'
import { useDevil } from './devil-store'
import { AVATAR_FLOAT, DevilAvatar, bodyDims } from './devil-avatar'
import { BlackCat, FlyingCreature, Magpie } from './companions'
import { SmokeTransformation } from './fx'

function CameraRig({ mode, form, headY }: { mode: CameraMode; form: Form; headY: number }) {
  const target = useMemo(() => new THREE.Vector3(0, 2, 0), [])
  const desiredPos = useMemo(() => new THREE.Vector3(), [])
  const desiredTarget = useMemo(() => new THREE.Vector3(), [])

  useFrame((state, delta) => {
    const face = mode === 'face' && form === 'devil'
    const narrow = state.size.width < 640
    const px = state.pointer.x
    const py = state.pointer.y
    if (face) {
      desiredPos.set(px * 0.35, headY + 0.05 + py * 0.12, narrow ? 1.9 : 1.45)
      desiredTarget.set(0, headY, 0)
    } else {
      desiredPos.set(px * 1.1, 2.15 + py * 0.4, narrow ? 9.5 : 7.4)
      desiredTarget.set(0, 1.95, 0)
    }
    const cam = state.camera
    cam.position.x = THREE.MathUtils.damp(cam.position.x, desiredPos.x, 2.6, delta)
    cam.position.y = THREE.MathUtils.damp(cam.position.y, desiredPos.y, 2.6, delta)
    cam.position.z = THREE.MathUtils.damp(cam.position.z, desiredPos.z, 2.6, delta)
    target.x = THREE.MathUtils.damp(target.x, desiredTarget.x, 3, delta)
    target.y = THREE.MathUtils.damp(target.y, desiredTarget.y, 3, delta)
    target.z = THREE.MathUtils.damp(target.z, desiredTarget.z, 3, delta)
    cam.lookAt(target)
  })
  return null
}

function SceneContents() {
  const { state, active } = useDevil()
  const { config, alignment, locked } = active
  const scale = BUILD_SCALE[config.build]
  const dims = bodyDims(config.gender)
  const catPos = useRef(new THREE.Vector3())
  const creaturePos = useRef(new THREE.Vector3())
  const lastForm = useRef<Form>(state.form)
  const prevFormForSmoke = useRef<Form>(state.form)

  if (lastForm.current !== state.form) {
    prevFormForSmoke.current = lastForm.current
    lastForm.current = state.form
  }

  const getSmokeOrigins = useCallback(() => {
    const origins = [new THREE.Vector3(0, 2.1 * scale[1], 0)]
    if (prevFormForSmoke.current === 'cat') origins.push(catPos.current.clone())
    if (prevFormForSmoke.current === 'creature') origins.push(creaturePos.current.clone())
    if (state.form === 'creature') origins.push(new THREE.Vector3(0, 2.4, 0))
    return origins
  }, [scale, state.form])

  const activeChakras = Object.keys(state.chakras)
  const shoulder: [number, number, number] = [-(dims.shoulderX + 0.04) * scale[0], 2.9 * scale[1], 0]
  const headY = (3.08 + AVATAR_FLOAT) * scale[1]
  const accent = alignment === 'angel' ? '#ffd58a' : '#ff2a3d'

  return (
    <>
      <color attach="background" args={['#06040a']} />
      <fog attach="fog" args={['#06040a', 9, 24]} />

      <ambientLight intensity={0.18} />
      <hemisphereLight args={['#5a3a6a', '#1a0505', 0.35]} />
      <spotLight position={[3.5, 6, 5]} angle={0.5} penumbra={0.8} intensity={38} color="#ffd9b0" castShadow shadow-mapSize={[1024, 1024]} />
      <pointLight position={[-3, 3.2, -2.5]} intensity={22} color={accent} distance={10} />
      <pointLight position={[3, 2.5, -3]} intensity={18} color="#d4a64a" distance={10} />
      <pointLight position={[0, 0.4, 2.2]} intensity={2} color="#ff5a1a" distance={4} />

      <Stars radius={40} depth={20} count={1800} factor={2.2} saturation={0} fade speed={0.4} />
      <Sparkles count={120} scale={[14, 7, 8]} position={[0, 3, -2]} size={2} speed={0.25} color="#ff7a3a" opacity={0.6} />

      <CameraRig mode={state.camera} form={state.form} headY={headY} />

      <group scale={1}>
        <DevilAvatar
          config={config}
          alignment={alignment}
          visible={state.form === 'devil'}
          locked={locked}
          action={state.action}
          activeChakras={activeChakras}
        />
      </group>

      <Magpie perched={state.form === 'devil'} shoulder={shoulder} />
      <BlackCat active={state.form === 'cat'} posRef={catPos} />
      <FlyingCreature kind={state.form === 'creature' ? state.creature : null} posRef={creaturePos} />
      <SmokeTransformation trigger={state.smokeKey} getOrigins={getSmokeOrigins} />

      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[14, 64]} />
        <meshStandardMaterial color="#0b0709" roughness={0.35} metalness={0.7} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.005, 0]}>
        <ringGeometry args={[1.9, 1.94, 96]} />
        <meshBasicMaterial color="#d4a64a" transparent opacity={0.55} toneMapped={false} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.005, 0]}>
        <ringGeometry args={[2.3, 2.315, 96]} />
        <meshBasicMaterial color={accent} transparent opacity={0.5} toneMapped={false} />
      </mesh>
      <ContactShadows position={[0, 0.01, 0]} opacity={0.6} scale={8} blur={2.4} far={4} />

      <EffectComposer multisampling={0}>
        <Bloom mipmapBlur luminanceThreshold={0.9} intensity={1.1} radius={0.7} />
        <Vignette eskil={false} offset={0.2} darkness={0.85} />
      </EffectComposer>
    </>
  )
}

export default function DevilScene() {
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [0, 2.2, 8], fov: 38, near: 0.05, far: 80 }}
      gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping, outputColorSpace: THREE.SRGBColorSpace }}
      aria-label="3D devil avatar stage"
    >
      <SceneContents />
    </Canvas>
  )
}
