import * as THREE from 'three'

let glowTexture: THREE.CanvasTexture | null = null

export function getGlowTexture() {
  if (glowTexture) return glowTexture
  const size = 128
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  gradient.addColorStop(0, 'rgba(255,255,255,1)')
  gradient.addColorStop(0.35, 'rgba(255,255,255,0.55)')
  gradient.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, size, size)
  glowTexture = new THREE.CanvasTexture(canvas)
  glowTexture.colorSpace = THREE.SRGBColorSpace
  return glowTexture
}

export function makeTaperedTube(
  points: THREE.Vector3[],
  radius: number,
  tipScale = 0.05,
  tubularSegments = 40,
  radialSegments = 12,
) {
  const curve = new THREE.CatmullRomCurve3(points)
  const geometry = new THREE.TubeGeometry(curve, tubularSegments, radius, radialSegments, false)
  const position = geometry.attributes.position as THREE.BufferAttribute
  const vertex = new THREE.Vector3()
  for (let i = 0; i <= tubularSegments; i++) {
    const t = i / tubularSegments
    const center = curve.getPointAt(t)
    const taper = 1 - (1 - tipScale) * Math.pow(t, 0.9)
    for (let j = 0; j <= radialSegments; j++) {
      const idx = i * (radialSegments + 1) + j
      vertex.fromBufferAttribute(position, idx)
      vertex.sub(center).multiplyScalar(taper).add(center)
      position.setXYZ(idx, vertex.x, vertex.y, vertex.z)
    }
  }
  position.needsUpdate = true
  geometry.computeVertexNormals()
  return { geometry, curve }
}

export function segmentTransform(start: [number, number, number], end: [number, number, number]) {
  const a = new THREE.Vector3(...start)
  const b = new THREE.Vector3(...end)
  const dir = b.clone().sub(a)
  const length = dir.length()
  const quaternion = new THREE.Quaternion().setFromUnitVectors(
    new THREE.Vector3(0, 1, 0),
    dir.normalize(),
  )
  const mid = a.add(b).multiplyScalar(0.5)
  return { position: mid, quaternion, length }
}

export function hornPoints(style: 'curved' | 'straight' | 'ram') {
  if (style === 'straight') {
    return [
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0.04, 0.22, -0.03),
      new THREE.Vector3(0.08, 0.46, -0.06),
      new THREE.Vector3(0.11, 0.7, -0.08),
    ]
  }
  if (style === 'ram') {
    const pts: THREE.Vector3[] = []
    const steps = 16
    for (let k = 0; k <= steps; k++) {
      const a = (k / steps) * Math.PI * 1.75
      const r = 0.2 * (1 - k / (steps * 1.6))
      pts.push(new THREE.Vector3(0.02 + k * 0.011, r * Math.sin(a), -(0.2 - r * Math.cos(a))))
    }
    return pts
  }
  return [
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(0.1, 0.18, -0.06),
    new THREE.Vector3(0.17, 0.38, -0.04),
    new THREE.Vector3(0.14, 0.56, 0.08),
    new THREE.Vector3(0.07, 0.66, 0.18),
  ]
}

export function makeBatWingShape() {
  const shape = new THREE.Shape()
  shape.moveTo(0, 0.1)
  shape.quadraticCurveTo(0.5, 0.9, 1.0, 1.15)
  shape.lineTo(1.75, 1.35)
  shape.quadraticCurveTo(1.55, 0.6, 1.6, -0.2)
  shape.quadraticCurveTo(1.25, 0.05, 1.05, -0.55)
  shape.quadraticCurveTo(0.8, -0.25, 0.55, -0.75)
  shape.quadraticCurveTo(0.35, -0.35, 0.05, -0.45)
  shape.lineTo(0, 0.1)
  return shape
}

export const BAT_WING_BONES: [[number, number, number], [number, number, number]][] = [
  [[0, 0.1, 0], [1.0, 1.15, 0]],
  [[1.0, 1.15, 0], [1.75, 1.35, 0]],
  [[1.0, 1.15, 0], [1.6, -0.2, 0]],
  [[1.0, 1.15, 0], [1.05, -0.55, 0]],
  [[1.0, 1.15, 0], [0.55, -0.75, 0]],
]
