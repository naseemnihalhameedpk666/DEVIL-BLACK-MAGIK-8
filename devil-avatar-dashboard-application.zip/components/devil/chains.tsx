'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { ParticleBurst } from './fx'

const RING_HEIGHTS = [1.78, 2.12, 2.46]
const BIND_DELAY = 0.75
const BIND_DURATION = 1.3
const SHATTER_DURATION = 1.8

interface LinkData {
  base: THREE.Matrix4
  pos: THREE.Vector3
  quat: THREE.Quaternion
  vel: THREE.Vector3
  spin: THREE.Vector3
  order: number
}

export function Chains({ locked, radius }: { locked: boolean; radius: number }) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const material = useRef<THREE.MeshStandardMaterial>(null)
  const lockedAt = useRef<number | null>(locked ? performance.now() / 1000 : null)
  const shatterAt = useRef<number | null>(null)
  const prevLocked = useRef(locked)
  const [shatterKey, setShatterKey] = useState(0)

  const links = useMemo<LinkData[]>(() => {
    const result: LinkData[] = []
    const xAxis = new THREE.Vector3(1, 0, 0)
    RING_HEIGHTS.forEach((h, ring) => {
      const count = Math.round((Math.PI * 2 * radius) / 0.085)
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2
        const tilt = Math.sin(a) * 0.09 * (ring % 2 ? 1 : -1)
        const pos = new THREE.Vector3(Math.cos(a) * radius, h + tilt, Math.sin(a) * radius * 0.82)
        const tangent = new THREE.Vector3(-Math.sin(a), 0, Math.cos(a) * 0.82).normalize()
        const quat = new THREE.Quaternion().setFromUnitVectors(xAxis, tangent)
        if (i % 2) quat.multiply(new THREE.Quaternion().setFromAxisAngle(xAxis, Math.PI / 2))
        const base = new THREE.Matrix4().compose(pos, quat, new THREE.Vector3(1.5, 1, 1))
        result.push({
          base,
          pos: pos.clone(),
          quat: quat.clone(),
          vel: new THREE.Vector3(),
          spin: new THREE.Vector3(),
          order: (ring + i / count) / RING_HEIGHTS.length,
        })
      }
    })
    return result
  }, [radius])

  useEffect(() => {
    if (locked && !prevLocked.current) {
      lockedAt.current = performance.now() / 1000
      shatterAt.current = null
    }
    if (!locked && prevLocked.current) {
      shatterAt.current = performance.now() / 1000
      lockedAt.current = null
      for (const link of links) {
        link.base.decompose(link.pos, link.quat, new THREE.Vector3())
        const outward = new THREE.Vector3(link.pos.x, 0, link.pos.z).normalize()
        link.vel.copy(outward.multiplyScalar(2 + Math.random() * 3)).add(new THREE.Vector3(0, 1 + Math.random() * 2.5, 0))
        link.spin.set(Math.random() * 12 - 6, Math.random() * 12 - 6, Math.random() * 12 - 6)
      }
      setShatterKey((k) => k + 1)
    }
    prevLocked.current = locked
  }, [locked, links])

  const temp = useMemo(() => ({ m: new THREE.Matrix4(), s: new THREE.Vector3(), q: new THREE.Quaternion(), e: new THREE.Euler() }), [])

  useFrame(({ clock }, delta) => {
    const im = mesh.current
    if (!im) return
    const now = performance.now() / 1000
    if (material.current) material.current.emissiveIntensity = 2.2 + Math.sin(clock.elapsedTime * 5) * 0.8

    if (lockedAt.current !== null) {
      const progress = THREE.MathUtils.clamp((now - lockedAt.current - BIND_DELAY) / BIND_DURATION, 0, 1)
      links.forEach((link, i) => {
        const local = THREE.MathUtils.clamp((progress - link.order * 0.85) / 0.15, 0, 1)
        const pop = local < 1 ? local * (1.25 - 0.25 * local) : 1
        temp.m.copy(link.base)
        temp.s.setScalar(pop)
        temp.m.scale(temp.s)
        im.setMatrixAt(i, temp.m)
      })
      im.visible = true
    } else if (shatterAt.current !== null) {
      const age = now - shatterAt.current
      if (age > SHATTER_DURATION) {
        im.visible = false
        shatterAt.current = null
      } else {
        const dt = Math.min(delta, 0.05)
        const fade = 1 - age / SHATTER_DURATION
        links.forEach((link, i) => {
          link.vel.y -= 6 * dt
          link.pos.addScaledVector(link.vel, dt)
          temp.e.set(link.spin.x * dt, link.spin.y * dt, link.spin.z * dt)
          link.quat.multiply(temp.q.setFromEuler(temp.e))
          temp.m.compose(link.pos, link.quat, temp.s.set(1.5 * fade, fade, fade))
          im.setMatrixAt(i, temp.m)
        })
        im.visible = true
      }
    } else {
      im.visible = false
    }
    im.instanceMatrix.needsUpdate = true
  })

  return (
    <group>
      <instancedMesh ref={mesh} args={[undefined, undefined, links.length]} visible={false} frustumCulled={false}>
        <torusGeometry args={[0.042, 0.013, 8, 16]} />
        <meshStandardMaterial ref={material} color="#3a1a0a" metalness={0.9} roughness={0.3} emissive="#ff5212" emissiveIntensity={2.4} toneMapped={false} />
      </instancedMesh>
      <ShadowHands locked={locked} />
      <ParticleBurst
        trigger={shatterKey}
        getOrigins={() => [new THREE.Vector3(0, 2.1, 0)]}
        count={500}
        color="#ff7a26"
        size={0.09}
        additive
        duration={2.2}
        speed={3.5}
        spread={[radius, 0.5, radius]}
        rise={2}
        gravity={2.5}
      />
      {locked && <EmberDrift />}
    </group>
  )
}

function EmberDrift() {
  const light = useRef<THREE.PointLight>(null)
  useFrame(({ clock }) => {
    if (light.current) light.current.intensity = 3 + Math.sin(clock.elapsedTime * 7) * 1.2
  })
  return <pointLight ref={light} position={[0, 2.1, 0.8]} color="#ff5a1a" distance={4} />
}

function ShadowHands({ locked }: { locked: boolean }) {
  const groups = useRef<(THREE.Group | null)[]>([])
  const material = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: '#12061a',
        emissive: '#7a1fff',
        emissiveIntensity: 0.9,
        roughness: 0.3,
        transparent: true,
        opacity: 0.88,
        toneMapped: false,
      }),
    [],
  )

  useFrame(({ clock }, delta) => {
    const t = clock.elapsedTime
    material.emissiveIntensity = 0.8 + Math.sin(t * 3) * 0.4
    groups.current.forEach((g, idx) => {
      if (!g) return
      const s = idx === 0 ? -1 : 1
      const targetX = locked ? s * 0.95 : s * 3.6
      g.position.x = THREE.MathUtils.damp(g.position.x, targetX, locked ? 3.2 : 4, delta)
      g.position.y = 2.25 + Math.sin(t * 1.3 + idx) * 0.05
      const scaleTarget = locked ? 1 : 0
      const sc = THREE.MathUtils.damp(g.scale.y, scaleTarget, 4, delta)
      g.scale.set(s * sc, sc, sc)
      g.visible = sc > 0.02
      const fingers = g.children[0] as THREE.Group
      fingers.children.forEach((f, i) => {
        if (i === 0) return
        f.rotation.x = THREE.MathUtils.damp(f.rotation.x, locked ? 0.9 : 0, 3, delta)
      })
    })
  })

  return (
    <>
      {[0, 1].map((idx) => (
        <group
          key={idx}
          ref={(el) => {
            groups.current[idx] = el
          }}
          position={[idx === 0 ? -3.6 : 3.6, 2.25, 0.35]}
          scale={0}
        >
          <group rotation={[0, 0, Math.PI / 2]}>
            <mesh material={material} scale={[1, 1.1, 0.4]}>
              <sphereGeometry args={[0.16, 24, 16]} />
            </mesh>
            {[-1.5, -0.5, 0.5, 1.5].map((f) => (
              <group key={f} position={[f * 0.07, 0.15, 0]}>
                <mesh material={material} position={[0, 0.1, 0]}>
                  <capsuleGeometry args={[0.028, 0.16, 6, 12]} />
                </mesh>
                <mesh material={material} position={[0, 0.25, 0.03]} rotation={[0.5, 0, 0]}>
                  <coneGeometry args={[0.02, 0.08, 8]} />
                </mesh>
              </group>
            ))}
            <mesh material={material} position={[0.17, 0.02, 0.05]} rotation={[0, 0, -0.9]}>
              <capsuleGeometry args={[0.03, 0.12, 6, 12]} />
            </mesh>
            <mesh material={material} position={[0, -0.28, 0]}>
              <capsuleGeometry args={[0.1, 0.3, 8, 16]} />
            </mesh>
            <pointLight color="#9b4dff" intensity={2} distance={1.6} />
          </group>
        </group>
      ))}
    </>
  )
}
