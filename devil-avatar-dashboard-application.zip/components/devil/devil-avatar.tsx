'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Sparkles } from '@react-three/drei'
import * as THREE from 'three'
import {
  BUILD_SCALE,
  CHAKRAS,
  EYE_LENSES,
  skinById,
  wingById,
  type ActionKind,
  type Alignment,
  type AvatarConfig,
} from '@/lib/devil-config'
import { BAT_WING_BONES, getGlowTexture, hornPoints, makeBatWingShape, makeTaperedTube, segmentTransform } from './three-utils'
import { Flame, ParticleBurst } from './fx'
import { Chains } from './chains'
import { ChakraRing } from './chakra-ring'

interface DevilAvatarProps {
  config: AvatarConfig
  alignment: Alignment
  visible: boolean
  locked: boolean
  action: { kind: ActionKind; key: number } | null
  activeChakras: string[]
}

export const AVATAR_FLOAT = 0.15

export function avatarFloat(t: number) {
  return AVATAR_FLOAT + Math.sin(t * 1.2) * 0.04
}

export function bodyDims(gender: AvatarConfig['gender']) {
  return gender === 'male'
    ? { shoulderX: 0.42, torso: [1.2, 1, 0.78] as const, waistX: 1.0, hip: [0.34, 0.22, 0.22] as const, armR: 0.085, thighR: 0.12, neckR: 0.12, jaw: 1.05, wing: 1 }
    : { shoulderX: 0.34, torso: [0.98, 1, 0.72] as const, waistX: 0.78, hip: [0.38, 0.24, 0.24] as const, armR: 0.066, thighR: 0.115, neckR: 0.095, jaw: 0.88, wing: 0.88 }
}

export function DevilAvatar({ config, alignment, visible, locked, action, activeChakras }: DevilAvatarProps) {
  const outer = useRef<THREE.Group>(null)
  const inner = useRef<THREE.Group>(null)
  const chest = useRef<THREE.Group>(null)
  const scale = BUILD_SCALE[config.build]
  const dims = bodyDims(config.gender)
  const skin = skinById(config.skin)
  const wing = wingById(config.wings)
  const eye = EYE_LENSES[config.eyes]
  const female = config.gender === 'female'
  const auraColor = alignment === 'angel' ? '#ffe3a1' : '#ff3b2f'
  const handsActive = action?.kind === 'hands' || action?.kind === 'both'
  const eyesActive = action?.kind === 'eyes' || action?.kind === 'both'

  const skinMat = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: skin.color,
        roughness: 0.48,
        metalness: 0.05,
        clearcoat: 0.35,
        clearcoatRoughness: 0.5,
        sheen: 0.6,
        sheenColor: new THREE.Color(skin.color).offsetHSL(0, 0, 0.25),
        sheenRoughness: 0.6,
      }),
    [skin.color],
  )
  const darkSkinMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: new THREE.Color(skin.color).multiplyScalar(0.35), roughness: 0.8 }),
    [skin.color],
  )
  const leatherMat = useMemo(
    () => new THREE.MeshPhysicalMaterial({ color: '#120c0e', roughness: 0.4, metalness: 0.3, clearcoat: 0.6, clearcoatRoughness: 0.3 }),
    [],
  )
  const goldMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#c99a3e', metalness: 1, roughness: 0.28, emissive: '#3a2400', emissiveIntensity: 0.4 }),
    [],
  )
  const hornMat = useMemo(
    () => new THREE.MeshPhysicalMaterial({ color: '#1b1210', roughness: 0.35, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.2 }),
    [],
  )
  const eyeMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: eye.iris, emissive: eye.glow, emissiveIntensity: 3, toneMapped: false }),
    [eye.iris, eye.glow],
  )
  const scleraMat = useMemo(() => new THREE.MeshStandardMaterial({ color: eye.sclera, roughness: 0.2 }), [eye.sclera])
  const wingMat = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: wing.color,
        emissive: wing.glow,
        emissiveIntensity: 0.18,
        roughness: 0.55,
        metalness: 0.1,
        sheen: 1,
        sheenColor: new THREE.Color(wing.glow),
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.94,
      }),
    [wing.color, wing.glow],
  )
  const boneMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: new THREE.Color(wing.color).multiplyScalar(0.6), roughness: 0.4, emissive: wing.glow, emissiveIntensity: 0.6 }),
    [wing.color, wing.glow],
  )
  const runeMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#ffcf6a', emissive: '#ffb02e', emissiveIntensity: 2.5, toneMapped: false }),
    [],
  )
  const hairMat = useMemo(
    () => new THREE.MeshPhysicalMaterial({ color: '#0b080a', roughness: 0.35, sheen: 1, sheenColor: new THREE.Color('#5a1830'), clearcoat: 0.4 }),
    [],
  )

  const wingShape = useMemo(() => makeBatWingShape(), [])
  const horn = useMemo(() => makeTaperedTube(hornPoints(config.horns), config.horns === 'ram' ? 0.065 : 0.06, 0.04), [config.horns])
  const tail = useMemo(() => {
    const t = makeTaperedTube(
      [
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, -0.25, -0.3),
        new THREE.Vector3(0.15, -0.55, -0.55),
        new THREE.Vector3(0.38, -0.55, -0.85),
        new THREE.Vector3(0.5, -0.25, -1.0),
      ],
      0.045,
      0.35,
    )
    const end = t.curve.getPointAt(1)
    const tangent = t.curve.getTangentAt(1)
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), tangent)
    return { geometry: t.geometry, end, q }
  }, [])

  const leftArm = useRef<THREE.Group>(null)
  const rightArm = useRef<THREE.Group>(null)
  const leftWing = useRef<THREE.Group>(null)
  const rightWing = useRef<THREE.Group>(null)
  const tailRef = useRef<THREE.Group>(null)
  const eyeLight = useRef<THREE.PointLight>(null)
  const beams = useRef<THREE.Group>(null)

  useFrame(({ clock }, delta) => {
    const t = clock.elapsedTime
    const o = outer.current
    if (o) {
      const target = visible ? 1 : 0
      const s = THREE.MathUtils.damp(o.scale.x / scale[0], target, visible ? 3 : 9, delta)
      o.scale.set(s * scale[0], s * scale[1], s * scale[2])
      o.visible = s > 0.01
      o.rotation.y = Math.sin(t * 0.3) * 0.22
    }
    if (inner.current) inner.current.position.y = avatarFloat(t)
    if (chest.current) {
      const breath = Math.sin(t * 1.6)
      chest.current.scale.set(1 + breath * 0.012, 1 + breath * 0.018, 1 + breath * 0.025)
    }
    const flap = Math.sin(t * 1.5)
    const wingOpen = locked ? 0.15 : 0.5
    if (rightWing.current) {
      rightWing.current.rotation.y = wingOpen + flap * 0.16
      rightWing.current.rotation.z = flap * 0.05
    }
    if (leftWing.current) {
      leftWing.current.rotation.y = wingOpen + flap * 0.16
      leftWing.current.rotation.z = flap * 0.05
    }
    if (tailRef.current) {
      tailRef.current.rotation.y = Math.sin(t * 0.9) * 0.35
      tailRef.current.rotation.x = Math.sin(t * 0.7) * 0.08
    }
    const armRaise = handsActive ? -1.25 : locked ? -0.05 : -0.3
    for (const arm of [leftArm.current, rightArm.current]) {
      if (!arm) continue
      const elbow = arm.children[arm.children.length - 1] as THREE.Group
      elbow.rotation.x = THREE.MathUtils.damp(elbow.rotation.x, armRaise, 6, delta)
      arm.rotation.x = THREE.MathUtils.damp(arm.rotation.x, handsActive ? -0.35 : Math.sin(t * 1.6) * 0.03, 6, delta)
    }
    const glow = 2.6 + Math.sin(t * 2.4) * 0.9 + (eyesActive ? 4 : 0)
    eyeMat.emissiveIntensity = glow
    runeMat.emissiveIntensity = 1.8 + Math.sin(t * 1.8) * 0.8
    wingMat.emissiveIntensity = 0.14 + (Math.sin(t * 1.2) + 1) * 0.08
    if (eyeLight.current) eyeLight.current.intensity = eyesActive ? 2.2 : 0.12 + Math.sin(t * 2.4) * 0.05
    if (beams.current) {
      const target = eyesActive ? 1 : 0
      const s = THREE.MathUtils.damp(beams.current.scale.z, target, 10, delta)
      beams.current.scale.set(1 + Math.sin(t * 40) * 0.08 * target, 1 + Math.cos(t * 37) * 0.08 * target, Math.max(s, 0.0001))
      beams.current.visible = s > 0.02
    }
  })

  const sides = [-1, 1] as const

  return (
    <group ref={outer}>
      <group ref={inner} position={[0, AVATAR_FLOAT, 0]}>
        <Sparkles count={70} scale={[2.6, 4, 2.2]} position={[0, 2, 0]} size={3} speed={0.4} color={auraColor} opacity={0.9} />

        {/* Torso */}
        <group ref={chest}>
          <mesh material={skinMat} position={[0, 2.32, 0]} scale={[dims.torso[0] * 1.05, 0.82, dims.torso[2] * 0.95]} castShadow>
            <sphereGeometry args={[0.33, 40, 32]} />
          </mesh>
          <mesh material={skinMat} position={[0, 1.95, 0]} scale={[dims.waistX, 1, 0.7]} castShadow>
            <capsuleGeometry args={[0.25, 0.25, 12, 24]} />
          </mesh>
          {female ? (
            <group>
              {sides.map((s) => (
                <mesh key={s} material={leatherMat} position={[s * 0.115, 2.33, 0.17]} scale={[1, 0.95, 0.85]}>
                  <sphereGeometry args={[0.125, 28, 20]} />
                </mesh>
              ))}
              <mesh material={leatherMat} position={[0, 2.22, 0.02]} scale={[dims.torso[0] * 0.98, 0.5, dims.torso[2] * 0.98]}>
                <cylinderGeometry args={[0.31, 0.27, 0.3, 32, 1, true]} />
              </mesh>
              <mesh material={goldMat} position={[0, 2.39, 0.27]}>
                <octahedronGeometry args={[0.035]} />
              </mesh>
            </group>
          ) : (
            <group>
              {sides.map((s) => (
                <mesh key={s} material={skinMat} position={[s * 0.15, 2.42, 0.18]} scale={[1.15, 0.8, 0.5]}>
                  <sphereGeometry args={[0.15, 28, 20]} />
                </mesh>
              ))}
              {[0, 1, 2].map((row) =>
                sides.map((s) => (
                  <mesh key={`${row}${s}`} material={skinMat} position={[s * 0.065, 2.12 - row * 0.12, 0.19]} scale={[1, 0.8, 0.45]}>
                    <sphereGeometry args={[0.06, 16, 12]} />
                  </mesh>
                )),
              )}
            </group>
          )}
          {config.markings === 'runes' && (
            <group>
              <mesh material={runeMat} position={[0, 2.3, female ? 0.29 : 0.26]}>
                <torusGeometry args={[0.07, 0.006, 8, 32]} />
              </mesh>
              {[0, 1, 2, 3].map((i) => (
                <mesh key={i} material={runeMat} position={[Math.cos((i * Math.PI) / 2) * 0.07, 2.3 + Math.sin((i * Math.PI) / 2) * 0.07, female ? 0.292 : 0.262]} rotation={[0, 0, (i * Math.PI) / 2]}>
                  <boxGeometry args={[0.005, 0.05, 0.004]} />
                </mesh>
              ))}
            </group>
          )}
        </group>

        {/* Shoulders + collar */}
        {sides.map((s) => (
          <mesh key={s} material={skinMat} position={[s * dims.shoulderX, 2.58, 0]} castShadow>
            <sphereGeometry args={[dims.armR * 1.9, 24, 20]} />
          </mesh>
        ))}
        {sides.map((s) => (
          <group key={`pauldron${s}`} position={[s * (dims.shoulderX + 0.02), 2.66, 0]} rotation={[0, 0, s * -0.5]}>
            <mesh material={leatherMat} scale={[1, 0.6, 1]}>
              <sphereGeometry args={[dims.armR * 2.1, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
            </mesh>
            <mesh material={goldMat} position={[0, 0.03, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[1, 1, 0.6]}>
              <torusGeometry args={[dims.armR * 2.05, 0.008, 8, 32]} />
            </mesh>
          </group>
        ))}

        {/* Pelvis, belt, armored skirt */}
        <mesh material={skinMat} position={[0, 1.62, 0]} scale={dims.hip as unknown as [number, number, number]}>
          <sphereGeometry args={[1, 32, 24]} />
        </mesh>
        <mesh material={goldMat} position={[0, 1.74, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[dims.hip[0] / 0.33, dims.hip[2] / 0.26, 1]}>
          <torusGeometry args={[0.3, 0.025, 12, 48]} />
        </mesh>
        <mesh material={leatherMat} position={[0, 1.45, 0]} scale={[dims.hip[0] / 0.33, 1, dims.hip[2] / 0.25]}>
          <cylinderGeometry args={[0.31, 0.4, 0.55, 32, 1, true]} />
        </mesh>

        {/* Neck */}
        <mesh material={skinMat} position={[0, 2.8, 0]}>
          <cylinderGeometry args={[dims.neckR * 0.9, dims.neckR * 1.15, 0.28, 20]} />
        </mesh>

        {/* Head */}
        <group position={[0, 3.08, 0.02]}>
          <mesh material={skinMat} scale={[0.92, 1.08, 0.98]} castShadow>
            <sphereGeometry args={[0.24, 48, 40]} />
          </mesh>
          <mesh material={skinMat} position={[0, -0.12, 0.04]} scale={[dims.jaw, 0.82, 1]}>
            <sphereGeometry args={[0.17, 32, 24]} />
          </mesh>
          <mesh material={skinMat} position={[0, -0.24, 0.12]} scale={[female ? 0.6 : 0.9, 0.6, 0.6]}>
            <sphereGeometry args={[0.07, 20, 16]} />
          </mesh>
          {/* cheekbones */}
          {sides.map((s) => (
            <mesh key={s} material={skinMat} position={[s * 0.12, -0.04, 0.15]} scale={[1, 0.6, 0.7]}>
              <sphereGeometry args={[0.06, 16, 12]} />
            </mesh>
          ))}
          {/* brow ridge */}
          <mesh material={skinMat} position={[0, 0.075, 0.185]} scale={[1, 0.35, 0.5]}>
            <sphereGeometry args={[0.15, 24, 16]} />
          </mesh>
          {/* nose */}
          <mesh material={skinMat} position={[0, -0.03, 0.235]} rotation={[Math.PI / 2.4, 0, 0]}>
            <coneGeometry args={[0.03, 0.1, 12]} />
          </mesh>
          {/* mouth + fangs */}
          <mesh material={darkSkinMat} position={[0, -0.135, 0.2]} scale={[1, 0.25, 0.5]}>
            <sphereGeometry args={[0.055, 16, 8]} />
          </mesh>
          {sides.map((s) => (
            <mesh key={`fang${s}`} position={[s * 0.028, -0.152, 0.208]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.008, 0.035, 8]} />
              <meshStandardMaterial color="#f1e9dc" roughness={0.2} />
            </mesh>
          ))}
          {/* eyes */}
          {sides.map((s) => (
            <group key={`eye${s}`} position={[s * 0.083, 0.025, 0.198]}>
              <mesh material={darkSkinMat} scale={[1.25, 0.7, 0.6]}>
                <sphereGeometry args={[0.04, 16, 12]} />
              </mesh>
              <mesh material={config.eyes === 'void' ? scleraMat : eyeMat} position={[0, 0, 0.012]} scale={[1.2, 0.62, 0.6]}>
                <sphereGeometry args={[0.03, 20, 16]} />
              </mesh>
              {config.eyes === 'void' ? (
                <mesh material={eyeMat} position={[0, 0, 0.03]} scale={[1, 1, 0.4]}>
                  <sphereGeometry args={[0.012, 12, 12]} />
                </mesh>
              ) : (
                <mesh position={[0, 0, 0.031]} scale={[0.25, 1, 0.3]}>
                  <sphereGeometry args={[0.016, 12, 12]} />
                  <meshBasicMaterial color="#050000" />
                </mesh>
              )}
              <sprite scale={0.14} position={[0, 0, 0.04]}>
                <spriteMaterial map={getGlowTexture()} color={eye.glow} blending={THREE.AdditiveBlending} transparent opacity={0.8} depthWrite={false} toneMapped={false} />
              </sprite>
            </group>
          ))}
          <pointLight ref={eyeLight} position={[0, 0.03, 0.55]} color={eye.glow} intensity={0.12} distance={0.7} />
          {/* eye fire beams */}
          <group ref={beams} position={[0, 0.025, 0.22]} visible={false}>
            {sides.map((s) => (
              <group key={`beam${s}`} position={[s * 0.083, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
                <mesh position={[0, 1.8, 0]}>
                  <cylinderGeometry args={[0.16, 0.02, 3.6, 16, 1, true]} />
                  <meshBasicMaterial color={eye.glow} transparent opacity={0.55} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} side={THREE.DoubleSide} />
                </mesh>
                <mesh position={[0, 1.8, 0]}>
                  <cylinderGeometry args={[0.05, 0.01, 3.6, 12, 1, true]} />
                  <meshBasicMaterial color="#fff2c0" transparent opacity={0.95} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} />
                </mesh>
              </group>
            ))}
          </group>
          {/* eyebrows */}
          {config.eyebrows !== 'none' &&
            sides.map((s) => (
              <group key={`brow${s}`} position={[s * 0.085, 0.085, 0.222]}>
                {config.eyebrows === 'arched' ? (
                  <mesh material={hairMat} rotation={[0, 0, Math.PI / 2 - 0.1 * s]} position={[0, -0.03, 0]}>
                    <torusGeometry args={[0.055, 0.007, 8, 24, Math.PI * 0.55]} />
                  </mesh>
                ) : (
                  <mesh
                    material={hairMat}
                    rotation={[0, 0, config.eyebrows === 'fierce' ? s * 0.38 : s * 0.08]}
                    scale={config.eyebrows === 'heavy' ? [1.1, 2.1, 1.4] : [1, 1, 1]}
                  >
                    <boxGeometry args={[0.085, 0.014, 0.014]} />
                  </mesh>
                )}
              </group>
            ))}
          {/* pointed ears */}
          {sides.map((s) => (
            <mesh key={`ear${s}`} material={skinMat} position={[s * 0.22, 0.01, -0.02]} rotation={[-0.3, 0, s * -1.25]} scale={[1, 1, 0.4]}>
              <coneGeometry args={[0.045, 0.18, 12]} />
            </mesh>
          ))}
          {/* horns */}
          {sides.map((s) => (
            <group key={`horn${s}`} position={[s * 0.12, 0.17, 0.06]} scale={[s, 1, 1]}>
              <mesh geometry={horn.geometry} material={hornMat} castShadow />
            </group>
          ))}
          {/* female hair */}
          {female && (
            <group>
              <mesh material={hairMat} rotation={[-0.45, 0, 0]} scale={[1.02, 1.08, 1.06]}>
                <sphereGeometry args={[0.255, 40, 24, 0, Math.PI * 2, 0, Math.PI * 0.52]} />
              </mesh>
              <mesh material={hairMat} position={[0, -0.42, -0.14]} scale={[1.1, 1, 0.55]}>
                <capsuleGeometry args={[0.19, 0.55, 12, 24]} />
              </mesh>
              {sides.map((s) => (
                <mesh key={`lock${s}`} material={hairMat} position={[s * 0.2, -0.28, 0.02]} rotation={[0, 0, s * 0.1]} scale={[0.5, 1, 0.5]}>
                  <capsuleGeometry args={[0.07, 0.4, 8, 16]} />
                </mesh>
              ))}
            </group>
          )}
          {/* markings */}
          {config.markings === 'scars' && (
            <group>
              {[0, 1, 2].map((i) => (
                <mesh key={i} material={darkSkinMat} position={[0.075 + i * 0.022, 0.03 - i * 0.01, 0.222]} rotation={[0, 0.3, -0.55]}>
                  <boxGeometry args={[0.006, 0.17, 0.006]} />
                </mesh>
              ))}
              <mesh material={darkSkinMat} position={[-0.12, -0.08, 0.18]} rotation={[0, -0.6, 0.9]}>
                <boxGeometry args={[0.006, 0.1, 0.006]} />
              </mesh>
            </group>
          )}
          {config.markings === 'runes' && (
            <group>
              <mesh material={runeMat} position={[0, 0.15, 0.215]}>
                <torusGeometry args={[0.025, 0.004, 6, 24]} />
              </mesh>
              <mesh material={runeMat} position={[0, 0.15, 0.218]}>
                <boxGeometry args={[0.004, 0.07, 0.003]} />
              </mesh>
              {sides.map((s) => (
                <mesh key={s} material={runeMat} position={[s * 0.15, -0.06, 0.16]} rotation={[0, s * 0.8, s * 0.3]}>
                  <boxGeometry args={[0.004, 0.06, 0.003]} />
                </mesh>
              ))}
            </group>
          )}
          {alignment === 'angel' && (
            <mesh position={[0, 0.48, -0.05]} rotation={[Math.PI / 2.3, 0, 0]}>
              <torusGeometry args={[0.2, 0.012, 12, 64, Math.PI * 1.7]} />
              <meshStandardMaterial color="#ffe6a8" emissive="#ffcf6a" emissiveIntensity={3} toneMapped={false} />
            </mesh>
          )}
        </group>

        {/* Arms */}
        {sides.map((s) => (
          <group key={`arm${s}`} ref={s === -1 ? leftArm : rightArm} position={[s * dims.shoulderX, 2.58, 0]} rotation={[0, 0, s * 0.18]}>
            <mesh material={skinMat} position={[0, -0.3, 0]} castShadow>
              <capsuleGeometry args={[dims.armR, 0.4, 10, 20]} />
            </mesh>
            {config.markings === 'runes' &&
              [0, 1, 2].map((i) => (
                <mesh key={i} material={runeMat} position={[0, -0.18 - i * 0.12, dims.armR * 0.96]}>
                  <boxGeometry args={[0.035, 0.006, 0.004]} />
                </mesh>
              ))}
            <group position={[0, -0.62, 0]} rotation={[-0.3, 0, 0]}>
              <mesh material={skinMat}>
                <sphereGeometry args={[dims.armR * 0.95, 16, 12]} />
              </mesh>
              <mesh material={skinMat} position={[0, -0.27, 0]} castShadow>
                <capsuleGeometry args={[dims.armR * 0.85, 0.36, 10, 20]} />
              </mesh>
              <mesh material={goldMat} position={[0, -0.4, 0]}>
                <cylinderGeometry args={[dims.armR * 0.98, dims.armR * 0.95, 0.06, 20]} />
              </mesh>
              <group position={[0, -0.6, 0]}>
                <mesh material={skinMat} scale={[0.9, 1.2, 0.6]}>
                  <sphereGeometry args={[dims.armR * 1.15, 20, 16]} />
                </mesh>
                {[-1.5, -0.5, 0.5, 1.5].map((f) => (
                  <mesh key={f} material={hornMat} position={[f * dims.armR * 0.38, -dims.armR * 1.45, dims.armR * 0.15]} rotation={[Math.PI + 0.25, 0, 0]}>
                    <coneGeometry args={[0.012, 0.07, 8]} />
                  </mesh>
                ))}
                {handsActive && <HandHellfire key={action?.key} trigger={action?.key ?? 0} />}
              </group>
            </group>
          </group>
        ))}

        {/* Legs */}
        {sides.map((s) => (
          <group key={`leg${s}`} position={[s * dims.hip[0] * 0.55, 1.55, 0]} rotation={[0, 0, s * 0.04]}>
            <mesh material={skinMat} position={[0, -0.32, 0]} castShadow>
              <capsuleGeometry args={[dims.thighR, 0.45, 10, 20]} />
            </mesh>
            <group position={[0, -0.7, 0]}>
              <mesh material={leatherMat} position={[0, 0.02, 0.03]} scale={[1, 1, 0.8]}>
                <sphereGeometry args={[dims.thighR * 0.9, 16, 12]} />
              </mesh>
              <mesh material={leatherMat} position={[0, -0.3, 0]} castShadow>
                <capsuleGeometry args={[dims.thighR * 0.78, 0.44, 10, 20]} />
              </mesh>
              <mesh material={hornMat} position={[0, -0.66, 0.03]}>
                <cylinderGeometry args={[0.07, 0.1, 0.12, 16]} />
              </mesh>
              <mesh material={hornMat} position={[0, -0.69, 0.11]} scale={[1, 0.5, 1.3]}>
                <sphereGeometry args={[0.07, 16, 12]} />
              </mesh>
            </group>
          </group>
        ))}

        {/* Tail */}
        <group ref={tailRef} position={[0, 1.62, -0.2]}>
          <mesh geometry={tail.geometry} material={skinMat} />
          <mesh position={tail.end} quaternion={tail.q} scale={[1, 1, 0.3]} material={darkSkinMat}>
            <coneGeometry args={[0.07, 0.16, 4]} />
          </mesh>
        </group>

        {/* Wings */}
        {sides.map((s) => (
          <group key={`wing${s}`} position={[s * 0.14, 2.5, -0.22]} scale={[s * dims.wing, dims.wing, dims.wing]}>
            <group ref={s === 1 ? rightWing : leftWing}>
              <mesh material={wingMat} castShadow>
                <shapeGeometry args={[wingShape, 24]} />
              </mesh>
              {BAT_WING_BONES.map(([a, b], i) => {
                const seg = segmentTransform(a, b)
                return (
                  <mesh key={i} material={boneMat} position={seg.position} quaternion={seg.quaternion}>
                    <cylinderGeometry args={[i < 2 ? 0.028 : 0.016, i < 2 ? 0.035 : 0.022, seg.length, 8]} />
                  </mesh>
                )
              })}
              <mesh material={hornMat} position={[1.0, 1.15, 0]} rotation={[0, 0, 0.6]}>
                <coneGeometry args={[0.03, 0.12, 8]} />
              </mesh>
            </group>
          </group>
        ))}

        {/* Chakras */}
        {CHAKRAS.filter((c) => activeChakras.includes(c.id)).map((c) => (
          <ChakraRing key={c.id} chakra={c} widthScale={c.ringRadius > 0.4 ? dims.shoulderX / 0.42 : 1} />
        ))}

        <Chains locked={locked} radius={dims.shoulderX + 0.2} />
      </group>

      {/* ground aura */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <planeGeometry args={[3.6, 3.6]} />
        <meshBasicMaterial map={getGlowTexture()} color={auraColor} transparent opacity={0.55} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} />
      </mesh>
    </group>
  )
}

function HandHellfire({ trigger }: { trigger: number }) {
  return (
    <group position={[0, -0.08, 0.05]}>
      <Flame scale={1.6} color="#ff4d0d" core="#fff0a0" tongues={9} />
      <ParticleBurst
        trigger={trigger}
        getOrigins={() => [new THREE.Vector3(0, 0, 0)]}
        count={160}
        color="#ff6a1a"
        size={0.07}
        additive
        duration={1.4}
        speed={1.6}
        spread={[0.05, 0.05, 0.05]}
        rise={1.2}
      />
    </group>
  )
}
