'use client'

import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import type { Chakra } from '@/lib/devil-config'
import { Flame } from './fx'
import { getGlowTexture } from './three-utils'

const FLAME_COUNT = 6

export function ChakraRing({ chakra, widthScale = 1 }: { chakra: Chakra; widthScale?: number }) {
  const spin = useRef<THREE.Group>(null)
  const tilt = useRef<THREE.Mesh>(null)
  const core = useRef<THREE.Sprite>(null)
  const r = chakra.ringRadius * widthScale

  useFrame(({ clock }) => {
    const t = clock.elapsedTime
    if (spin.current) spin.current.rotation.y = t * 0.9
    if (tilt.current) tilt.current.rotation.z = t * -1.4
    if (core.current) core.current.scale.setScalar(0.32 + Math.sin(t * 4) * 0.05)
  })

  const frontZ = chakra.id === 'soulstar' ? 0 : chakra.ringRadius > 0.4 ? 0.3 : chakra.id === 'throat' ? 0.12 : 0.24

  return (
    <group position={[0, chakra.y, 0]}>
      <group ref={spin}>
        <mesh rotation={[Math.PI / 2, 0, 0]} scale={[1, 0.82, 1]}>
          <torusGeometry args={[r, 0.012, 10, 96]} />
          <meshBasicMaterial color={chakra.color} toneMapped={false} />
        </mesh>
        <mesh ref={tilt} rotation={[Math.PI / 2.4, 0.3, 0]}>
          <torusGeometry args={[r * 1.12, 0.006, 8, 96]} />
          <meshBasicMaterial color={chakra.color} transparent opacity={0.7} toneMapped={false} />
        </mesh>
        {Array.from({ length: FLAME_COUNT }, (_, i) => {
          const a = (i / FLAME_COUNT) * Math.PI * 2
          return (
            <group key={i} position={[Math.cos(a) * r, 0, Math.sin(a) * r * 0.82]}>
              <Flame color={chakra.color} core="#fff6dc" scale={0.55} tongues={4} light={false} />
            </group>
          )
        })}
      </group>
      <sprite ref={core} position={[0, 0, frontZ]}>
        <spriteMaterial map={getGlowTexture()} color={chakra.color} blending={THREE.AdditiveBlending} transparent depthWrite={false} toneMapped={false} />
      </sprite>
      <group position={[0, -0.05, frontZ]}>
        <Flame color={chakra.color} core="#ffffff" scale={0.9} tongues={6} />
      </group>
    </group>
  )
}
