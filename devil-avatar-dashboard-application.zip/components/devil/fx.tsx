'use client'

import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { getGlowTexture } from './three-utils'

interface FlameProps {
  color?: string
  core?: string
  scale?: number
  tongues?: number
  light?: boolean
}

export function Flame({ color = '#ff5a1a', core = '#ffe08a', scale = 1, tongues = 7, light = true }: FlameProps) {
  const group = useRef<THREE.Group>(null)
  const seeds = useMemo(
    () =>
      Array.from({ length: tongues }, (_, i) => ({
        angle: (i / tongues) * Math.PI * 2,
        radius: i === 0 ? 0 : 0.04 + Math.random() * 0.05,
        speed: 6 + Math.random() * 6,
        phase: Math.random() * 10,
        height: i === 0 ? 1.1 : 0.6 + Math.random() * 0.5,
      })),
    [tongues],
  )

  useFrame(({ clock }) => {
    const g = group.current
    if (!g) return
    const t = clock.elapsedTime
    g.children.forEach((child, i) => {
      const s = seeds[i]
      if (!s) return
      const flicker = 0.75 + Math.sin(t * s.speed + s.phase) * 0.18 + Math.sin(t * s.speed * 2.3 + s.phase) * 0.1
      child.scale.set(1, s.height * flicker, 1)
      child.position.set(
        Math.cos(s.angle + t) * s.radius,
        (0.15 * s.height * flicker) / 2,
        Math.sin(s.angle + t) * s.radius,
      )
      child.rotation.z = Math.sin(t * 3 + s.phase) * 0.15
    })
  })

  return (
    <group scale={scale}>
      <group ref={group}>
        {seeds.map((s, i) => (
          <mesh key={i}>
            <coneGeometry args={[i === 0 ? 0.07 : 0.045, 0.3, 10, 1, true]} />
            <meshBasicMaterial
              color={i === 0 ? core : color}
              transparent
              opacity={i === 0 ? 0.9 : 0.65}
              blending={THREE.AdditiveBlending}
              depthWrite={false}
              toneMapped={false}
              side={THREE.DoubleSide}
            />
          </mesh>
        ))}
      </group>
      <sprite scale={[0.55, 0.55, 0.55]} position={[0, 0.08, 0]}>
        <spriteMaterial
          map={getGlowTexture()}
          color={color}
          transparent
          opacity={0.7}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          toneMapped={false}
        />
      </sprite>
      {light && <pointLight color={color} intensity={2.5} distance={2.5} decay={2} />}
    </group>
  )
}

interface BurstProps {
  trigger: number
  getOrigins?: () => THREE.Vector3[]
  count?: number
  color?: string
  size?: number
  additive?: boolean
  duration?: number
  speed?: number
  spread?: [number, number, number]
  rise?: number
  gravity?: number
  opacity?: number
}

export function ParticleBurst({
  trigger,
  getOrigins,
  count = 600,
  color = '#3e2a3c',
  size = 0.5,
  additive = false,
  duration = 1.8,
  speed = 1.2,
  spread = [0.6, 1.8, 0.6],
  rise = 0.8,
  gravity = 0,
  opacity = 0.9,
}: BurstProps) {
  const points = useRef<THREE.Points>(null)
  const material = useRef<THREE.PointsMaterial>(null)
  const started = useRef(-1)
  const velocities = useMemo(() => new Float32Array(count * 3), [count])
  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 3), 3))
    return g
  }, [count])

  useEffect(() => {
    if (!trigger) return
    const origins = getOrigins?.() ?? [new THREE.Vector3(0, 2, 0)]
    const pos = geometry.attributes.position as THREE.BufferAttribute
    for (let i = 0; i < count; i++) {
      const o = origins[i % origins.length]
      const isPrimary = i % origins.length === 0
      const sx = isPrimary ? spread[0] : 0.3
      const sy = isPrimary ? spread[1] : 0.3
      const sz = isPrimary ? spread[2] : 0.3
      const theta = Math.random() * Math.PI * 2
      const r = Math.sqrt(Math.random())
      const ox = Math.cos(theta) * r * sx
      const oz = Math.sin(theta) * r * sz
      const oy = (Math.random() - 0.5) * 2 * sy
      pos.setXYZ(i, o.x + ox, o.y + oy, o.z + oz)
      const v = new THREE.Vector3(ox, oy * 0.3, oz).normalize().multiplyScalar(speed * (0.3 + Math.random()))
      velocities[i * 3] = v.x
      velocities[i * 3 + 1] = v.y + rise * Math.random()
      velocities[i * 3 + 2] = v.z
    }
    pos.needsUpdate = true
    started.current = performance.now() / 1000
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trigger])

  useFrame((_, delta) => {
    const p = points.current
    const m = material.current
    if (!p || !m) return
    if (started.current < 0) {
      p.visible = false
      return
    }
    const age = performance.now() / 1000 - started.current
    if (age > duration) {
      p.visible = false
      return
    }
    p.visible = true
    const k = age / duration
    m.opacity = opacity * (k < 0.15 ? k / 0.15 : 1 - (k - 0.15) / 0.85)
    m.size = size * (0.6 + k * 0.9)
    const pos = geometry.attributes.position as THREE.BufferAttribute
    const dt = Math.min(delta, 0.05)
    for (let i = 0; i < count; i++) {
      velocities[i * 3 + 1] -= gravity * dt
      velocities[i * 3] *= 0.985
      velocities[i * 3 + 2] *= 0.985
      pos.setXYZ(
        i,
        pos.getX(i) + velocities[i * 3] * dt,
        pos.getY(i) + velocities[i * 3 + 1] * dt,
        pos.getZ(i) + velocities[i * 3 + 2] * dt,
      )
    }
    pos.needsUpdate = true
  })

  return (
    <points ref={points} geometry={geometry} visible={false} frustumCulled={false}>
      <pointsMaterial
        ref={material}
        map={getGlowTexture()}
        color={color}
        size={size}
        sizeAttenuation
        transparent
        depthWrite={false}
        blending={additive ? THREE.AdditiveBlending : THREE.NormalBlending}
        toneMapped={!additive}
      />
    </points>
  )
}

export function SmokeTransformation({
  trigger,
  getOrigins,
}: {
  trigger: number
  getOrigins: () => THREE.Vector3[]
}) {
  return (
    <group>
      <ParticleBurst trigger={trigger} getOrigins={getOrigins} count={900} color="#3b2838" size={0.75} duration={2.2} speed={1.1} rise={1.2} />
      <ParticleBurst trigger={trigger} getOrigins={getOrigins} count={500} color="#120a10" size={0.9} duration={2} speed={0.8} rise={0.9} opacity={0.85} />
      <ParticleBurst trigger={trigger} getOrigins={getOrigins} count={260} color="#ff4a1a" size={0.08} additive duration={1.8} speed={2.2} rise={1.6} />
    </group>
  )
}
