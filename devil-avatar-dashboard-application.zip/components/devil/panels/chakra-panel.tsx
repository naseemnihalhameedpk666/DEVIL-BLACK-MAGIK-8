'use client'

import { CHAKRAS } from '@/lib/devil-config'
import { cn } from '@/lib/utils'
import { useDevil } from '../devil-store'
import { formatClock, useNow } from '../use-now'
import { Section } from './primitives'

export function ChakraPanel() {
  const { state, dispatch } = useDevil()
  const now = useNow()
  const activeCount = Object.keys(state.chakras).length

  return (
    <Section title="Chakra Flames" hint={`${activeCount} of ${CHAKRAS.length} burning`}>
      <ul className="flex flex-col gap-2">
        {CHAKRAS.map((c) => {
          const endsAt = state.chakras[c.id]
          const isOn = Boolean(endsAt)
          const remaining = endsAt && now ? endsAt - now : 0
          const pct = isOn ? (remaining / (c.minutes * 60_000)) * 100 : 0
          return (
            <li key={c.id}>
              <button
                type="button"
                aria-pressed={isOn}
                onClick={() => dispatch({ type: 'toggle-chakra', id: c.id, minutes: c.minutes, now: Date.now() })}
                className={cn(
                  'relative flex w-full items-center gap-3 overflow-hidden rounded-xl border p-3 text-left transition-colors',
                  isOn ? 'bg-secondary/80' : 'border-border bg-secondary/40 hover:border-gold/40',
                )}
                style={isOn ? { borderColor: `${c.color}99`, boxShadow: `inset 0 0 24px -12px ${c.color}` } : undefined}
              >
                <span
                  aria-hidden
                  className="size-8 shrink-0 rounded-full"
                  style={{
                    background: `radial-gradient(circle, #fff 0%, ${c.color} 45%, transparent 72%)`,
                    opacity: isOn ? 1 : 0.45,
                  }}
                />
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-medium text-foreground">{c.name}</span>
                  <span className="block text-xs text-muted-foreground">
                    {c.sanskrit} · {c.hz} Hz · {c.minutes} min
                  </span>
                </span>
                <span className="font-mono text-xs tabular-nums" style={{ color: isOn ? c.color : undefined }}>
                  {isOn ? formatClock(remaining) : 'Ignite'}
                </span>
                {isOn && (
                  <span
                    aria-hidden
                    className="absolute bottom-0 left-0 h-0.5 transition-[width] duration-1000 ease-linear"
                    style={{ width: `${pct}%`, background: c.color }}
                  />
                )}
              </button>
            </li>
          )
        })}
      </ul>
    </Section>
  )
}
