'use client'

import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

export function Section({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <section className="mb-5">
      <div className="mb-2 flex items-baseline justify-between gap-2">
        <h2 className="font-serif text-xs font-semibold tracking-[0.2em] text-gold">{title.toUpperCase()}</h2>
        {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
      </div>
      {children}
    </section>
  )
}

export function OptionGroup<T extends string>({
  label,
  options,
  value,
  onChange,
  disabled,
  columns = 3,
}: {
  label: string
  options: { value: T; label: string }[]
  value: T
  onChange: (v: T) => void
  disabled?: boolean
  columns?: 2 | 3 | 4
}) {
  return (
    <div
      role="radiogroup"
      aria-label={label}
      className={cn('grid gap-1.5', columns === 2 && 'grid-cols-2', columns === 3 && 'grid-cols-3', columns === 4 && 'grid-cols-4')}
    >
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          disabled={disabled}
          onClick={() => onChange(o.value)}
          className={cn(
            'rounded-lg border px-2 py-2 text-xs font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50',
            value === o.value
              ? 'border-gold/70 bg-gold/10 text-gold'
              : 'border-border bg-secondary/40 text-muted-foreground hover:border-gold/40 hover:text-foreground',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

export function SwatchGroup({
  label,
  options,
  value,
  onChange,
  disabled,
}: {
  label: string
  options: readonly { id: string; label: string; color: string; glow?: string }[]
  value: string
  onChange: (id: string) => void
  disabled?: boolean
}) {
  const current = options.find((o) => o.id === value)
  return (
    <div>
      <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            role="radio"
            aria-checked={value === o.id}
            aria-label={o.label}
            title={o.label}
            disabled={disabled}
            onClick={() => onChange(o.id)}
            className={cn(
              'size-9 rounded-full border-2 transition-transform disabled:cursor-not-allowed disabled:opacity-50',
              value === o.id ? 'scale-110 border-gold' : 'border-transparent hover:scale-105',
            )}
            style={{
              background: o.glow ? `radial-gradient(circle at 35% 30%, ${o.glow}, ${o.color} 65%)` : o.color,
              boxShadow: value === o.id ? `0 0 14px -2px ${o.glow ?? o.color}` : undefined,
            }}
          />
        ))}
      </div>
      {current && <p className="mt-1.5 text-[11px] text-muted-foreground">{current.label}</p>}
    </div>
  )
}
