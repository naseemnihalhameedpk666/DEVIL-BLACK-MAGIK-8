'use client'

import { useState, type FormEvent } from 'react'
import { ANGEL_NUMBERS, type AngelNumber } from '@/lib/devil-config'
import { cn } from '@/lib/utils'
import { useDevil } from '../devil-store'
import { Section } from './primitives'

export function MagicPanel() {
  const { state, active, dispatch } = useDevil()
  const [code, setCode] = useState('')
  const [error, setError] = useState<string | null>(null)

  const cast = (n: AngelNumber) => {
    setError(null)
    if (n.effect.type === 'creature') dispatch({ type: 'cast-creature', number: n.value, creature: n.effect.creature })
    else dispatch({ type: 'cast-action', number: n.value, action: n.effect.action })
  }

  const onSubmit = (e: FormEvent) => {
    e.preventDefault()
    const match = ANGEL_NUMBERS.find((n) => n.value === code.trim())
    if (!match) {
      setError('That sequence holds no power here.')
      return
    }
    cast(match)
    setCode('')
  }

  return (
    <div>
      <Section title="Angel Numbers" hint="Tap again to revert">
        <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-1">
          {ANGEL_NUMBERS.map((n) => {
            const isActive = state.activeNumber === n.value
            const blocked = active.locked && n.effect.type === 'creature'
            return (
              <li key={n.value}>
                <button
                  type="button"
                  onClick={() => cast(n)}
                  aria-pressed={isActive}
                  disabled={blocked}
                  className={cn(
                    'group flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-45',
                    isActive ? 'border-gold/70 bg-gold/10' : 'border-border bg-secondary/40 hover:border-gold/40',
                  )}
                >
                  <span
                    className={cn(
                      'font-serif text-2xl font-bold tabular-nums tracking-wider',
                      isActive ? 'text-gold' : 'text-foreground group-hover:text-gold',
                    )}
                  >
                    {n.value}
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-medium text-foreground">{n.title}</span>
                    <span className="block truncate text-xs text-muted-foreground">
                      {blocked ? 'Sealed while chained' : n.meaning}
                    </span>
                  </span>
                  <span
                    className={cn(
                      'ml-auto rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider',
                      n.effect.type === 'creature' ? 'bg-secondary text-muted-foreground' : 'bg-crimson/20 text-crimson',
                    )}
                  >
                    {n.effect.type === 'creature' ? 'Shift' : 'Cast'}
                  </span>
                </button>
              </li>
            )
          })}
        </ul>
      </Section>

      <Section title="Speak a Sequence">
        <form onSubmit={onSubmit} className="flex gap-2">
          <label htmlFor="angel-code" className="sr-only">
            Angel number
          </label>
          <input
            id="angel-code"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={4}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
            placeholder="e.g. 369"
            aria-invalid={Boolean(error)}
            aria-describedby={error ? 'angel-code-error' : undefined}
            className="h-10 flex-1 rounded-lg border border-input bg-background/60 px-3 font-mono text-sm tracking-widest text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
          <button
            type="submit"
            className="h-10 rounded-lg bg-gold px-4 font-serif text-sm font-semibold tracking-widest text-primary-foreground transition-opacity hover:opacity-90"
          >
            CAST
          </button>
        </form>
        {error && (
          <p id="angel-code-error" role="alert" className="mt-2 text-xs text-crimson">
            {error}
          </p>
        )}
      </Section>
    </div>
  )
}
