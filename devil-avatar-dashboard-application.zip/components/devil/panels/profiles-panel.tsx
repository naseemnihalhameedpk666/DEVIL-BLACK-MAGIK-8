'use client'

import { useState, type FormEvent } from 'react'
import { Lock, Plus, Trash2 } from 'lucide-react'
import { MAX_PROFILES, skinById, wingById, type Alignment } from '@/lib/devil-config'
import { cn } from '@/lib/utils'
import { useDevil } from '../devil-store'
import { OptionGroup, Section } from './primitives'

export function ProfilesPanel() {
  const { state, dispatch } = useDevil()
  const [name, setName] = useState('')
  const [alignment, setAlignment] = useState<Alignment>('devil')
  const full = state.profiles.length >= MAX_PROFILES

  const onSubmit = (e: FormEvent) => {
    e.preventDefault()
    if (full) return
    dispatch({ type: 'create-profile', name, alignment })
    setName('')
  }

  return (
    <div>
      <Section title="Profiles" hint={`${state.profiles.length} / ${MAX_PROFILES}`}>
        <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-2">
          {state.profiles.map((p) => {
            const selected = p.id === state.activeId
            const wing = wingById(p.config.wings)
            const skin = skinById(p.config.skin)
            return (
              <li key={p.id} className="relative">
                <button
                  type="button"
                  aria-pressed={selected}
                  onClick={() => dispatch({ type: 'select-profile', id: p.id })}
                  className={cn(
                    'flex w-full flex-col items-start gap-2 rounded-xl border p-3 text-left transition-colors',
                    selected ? 'border-gold/70 bg-gold/10' : 'border-border bg-secondary/40 hover:border-gold/40',
                  )}
                >
                  <span className="flex items-center gap-1" aria-hidden>
                    <span className="size-5 rounded-full border border-border" style={{ background: skin.color }} />
                    <span className="-ml-2 size-5 rounded-full border border-border" style={{ background: wing.glow }} />
                  </span>
                  <span className="w-full truncate font-serif text-xs font-semibold tracking-wider text-foreground">{p.name}</span>
                  <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <span className={cn('size-1.5 rounded-full', p.alignment === 'angel' ? 'bg-gold' : 'bg-crimson')} aria-hidden />
                    {p.alignment === 'angel' ? 'Angel' : 'Devil'}
                    {p.locked && (
                      <>
                        <Lock className="ml-1 size-3 text-gold" aria-hidden />
                        <span className="sr-only">locked</span>
                      </>
                    )}
                  </span>
                </button>
                {state.profiles.length > 1 && (
                  <button
                    type="button"
                    onClick={() => dispatch({ type: 'delete-profile', id: p.id })}
                    aria-label={`Delete profile ${p.name}`}
                    className="absolute right-2 top-2 rounded-md p-1 text-muted-foreground transition-colors hover:bg-crimson/20 hover:text-crimson"
                  >
                    <Trash2 className="size-3.5" aria-hidden />
                  </button>
                )}
              </li>
            )
          })}
        </ul>
      </Section>

      <Section title="Summon New Profile">
        <form onSubmit={onSubmit} className="flex flex-col gap-2">
          <label htmlFor="profile-name" className="sr-only">
            Profile name
          </label>
          <input
            id="profile-name"
            value={name}
            maxLength={24}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name your avatar"
            disabled={full}
            className="h-10 rounded-lg border border-input bg-background/60 px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
          />
          <OptionGroup
            label="New profile alignment"
            columns={2}
            value={alignment}
            onChange={setAlignment}
            disabled={full}
            options={[
              { value: 'devil', label: 'Devil' },
              { value: 'angel', label: 'Angel' },
            ]}
          />
          <button
            type="submit"
            disabled={full}
            className="flex h-10 items-center justify-center gap-2 rounded-lg bg-gold font-serif text-sm font-semibold tracking-widest text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
          >
            <Plus className="size-4" aria-hidden />
            {full ? 'ALL 18 SUMMONED' : 'SUMMON'}
          </button>
        </form>
      </Section>
    </div>
  )
}
