'use client'

import { Lock } from 'lucide-react'
import {
  EYE_LENSES,
  OPTION_LABELS,
  SKIN_TONES,
  WING_COLORS,
  type AvatarConfig,
  type EyeLensId,
} from '@/lib/devil-config'
import { useDevil } from '../devil-store'
import { OptionGroup, Section, SwatchGroup } from './primitives'

function toOptions<T extends string>(record: Record<T, string>) {
  return (Object.keys(record) as T[]).map((value) => ({ value, label: record[value] }))
}

export function AvatarPanel() {
  const { active, dispatch } = useDevil()
  const { config, locked } = active
  const set = (patch: Partial<AvatarConfig>) => dispatch({ type: 'update-config', patch })

  return (
    <div>
      {locked && (
        <p className="mb-4 flex items-center gap-2 rounded-lg border border-gold/40 bg-gold/10 px-3 py-2 text-xs text-gold">
          <Lock className="size-3.5" aria-hidden />
          Profile is chained. Unlock to customize.
        </p>
      )}

      <Section title="Alignment">
        <OptionGroup
          label="Alignment"
          columns={2}
          disabled={locked}
          value={active.alignment}
          onChange={(alignment) => dispatch({ type: 'set-alignment', alignment })}
          options={[
            { value: 'devil', label: 'Devil' },
            { value: 'angel', label: 'Angel' },
          ]}
        />
      </Section>

      <Section title="Form">
        <OptionGroup label="Gender" columns={2} disabled={locked} value={config.gender} onChange={(gender) => set({ gender })} options={toOptions(OPTION_LABELS.gender)} />
      </Section>

      <Section title="Wings">
        <SwatchGroup label="Wing color" options={WING_COLORS} value={config.wings} onChange={(wings) => set({ wings })} disabled={locked} />
      </Section>

      <Section title="Skin">
        <SwatchGroup label="Skin tone" options={SKIN_TONES} value={config.skin} onChange={(skin) => set({ skin })} disabled={locked} />
      </Section>

      <Section title="Eye Lens">
        <SwatchGroup
          label="Eye lens"
          options={(Object.keys(EYE_LENSES) as EyeLensId[]).map((id) => ({
            id,
            label: EYE_LENSES[id].label,
            color: EYE_LENSES[id].sclera,
            glow: EYE_LENSES[id].iris,
          }))}
          value={config.eyes}
          onChange={(eyes) => set({ eyes: eyes as EyeLensId })}
          disabled={locked}
        />
      </Section>

      <Section title="Horns">
        <OptionGroup label="Horn style" disabled={locked} value={config.horns} onChange={(horns) => set({ horns })} options={toOptions(OPTION_LABELS.horns)} />
      </Section>

      <Section title="Build">
        <OptionGroup label="Body build" disabled={locked} value={config.build} onChange={(build) => set({ build })} options={toOptions(OPTION_LABELS.build)} />
      </Section>

      <Section title="Eyebrows">
        <OptionGroup label="Eyebrow style" columns={4} disabled={locked} value={config.eyebrows} onChange={(eyebrows) => set({ eyebrows })} options={toOptions(OPTION_LABELS.eyebrows)} />
      </Section>

      <Section title="Markings">
        <OptionGroup label="Markings" disabled={locked} value={config.markings} onChange={(markings) => set({ markings })} options={toOptions(OPTION_LABELS.markings)} />
      </Section>
    </div>
  )
}
