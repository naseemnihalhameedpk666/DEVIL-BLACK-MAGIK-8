'use client'

import dynamic from 'next/dynamic'
import { DevilProvider } from './devil-store'
import { StageOverlay } from './stage-overlay'
import { ControlPanel } from './control-panel'

const DevilScene = dynamic(() => import('./devil-scene'), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <p className="animate-pulse font-serif text-sm tracking-[0.3em] text-gold/80">SUMMONING…</p>
    </div>
  ),
})

export function DevilDashboard() {
  return (
    <DevilProvider>
      <main className="flex min-h-dvh flex-col bg-background lg:h-dvh lg:flex-row lg:overflow-hidden">
        <section aria-label="Avatar stage" className="relative h-[60svh] w-full shrink-0 lg:h-full lg:flex-1">
          <DevilScene />
          <StageOverlay />
        </section>
        <ControlPanel />
      </main>
    </DevilProvider>
  )
}
