'use client'

import { useId, useState, type KeyboardEvent } from 'react'
import { Flame, Hash, Palette, Users } from 'lucide-react'
import { cn } from '@/lib/utils'
import { AvatarPanel } from './panels/avatar-panel'
import { MagicPanel } from './panels/magic-panel'
import { ChakraPanel } from './panels/chakra-panel'
import { ProfilesPanel } from './panels/profiles-panel'

const TABS = [
  { id: 'avatar', label: 'Avatar', icon: Palette, Panel: AvatarPanel },
  { id: 'magic', label: 'Numbers', icon: Hash, Panel: MagicPanel },
  { id: 'chakras', label: 'Chakras', icon: Flame, Panel: ChakraPanel },
  { id: 'profiles', label: 'Profiles', icon: Users, Panel: ProfilesPanel },
] as const

export function ControlPanel() {
  const [tab, setTab] = useState<(typeof TABS)[number]['id']>('avatar')
  const baseId = useId()
  const current = TABS.find((t) => t.id === tab)!

  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return
    const idx = TABS.findIndex((t) => t.id === tab)
    const next = TABS[(idx + (e.key === 'ArrowRight' ? 1 : TABS.length - 1)) % TABS.length]
    setTab(next.id)
    document.getElementById(`${baseId}-tab-${next.id}`)?.focus()
  }

  return (
    <aside
      aria-label="Avatar controls"
      className="flex w-full flex-col border-t border-border bg-card/80 lg:h-full lg:w-[400px] lg:shrink-0 lg:border-l lg:border-t-0"
    >
      <div
        role="tablist"
        aria-label="Control sections"
        onKeyDown={onKeyDown}
        className="sticky top-0 z-10 grid grid-cols-4 gap-1 border-b border-border bg-card/95 p-2 backdrop-blur"
      >
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            id={`${baseId}-tab-${id}`}
            type="button"
            role="tab"
            aria-selected={tab === id}
            aria-controls={`${baseId}-panel-${id}`}
            tabIndex={tab === id ? 0 : -1}
            onClick={() => setTab(id)}
            className={cn(
              'flex flex-col items-center gap-1 rounded-lg py-2 text-[11px] font-medium tracking-wide transition-colors',
              tab === id ? 'bg-secondary text-gold' : 'text-muted-foreground hover:bg-secondary/60 hover:text-foreground',
            )}
          >
            <Icon className="size-4" aria-hidden />
            {label}
          </button>
        ))}
      </div>
      <div
        id={`${baseId}-panel-${tab}`}
        role="tabpanel"
        aria-labelledby={`${baseId}-tab-${tab}`}
        className="flex-1 overflow-y-auto p-4"
      >
        <current.Panel />
      </div>
    </aside>
  )
}
