'use client'

import { useEffect, useMemo, useRef, useState, type MutableRefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, Sparkles } from '@react-three/drei'
import * as THREE from 'three'
import { CREATURE_WHISPERS, type CreatureKind } from '@/lib/devil-config'
import { BAT_WING_BONES, makeBatWingShape, makeTaperedTube, segmentTransform } from './three-utils'
import { avatarFloat } from './devil-avatar'

const Y_AXIS = new THREE.Vector3(0, 1, 0)

/* ---------------- Magpie companion with mini top hat ---------------- */

export function Magpie({
  perched,
  shoulder,
}: {
  perched: boolean
  shoulder: [number, number, number]
}) {
  const root = useRef<THREE.Group>(null)
  const leftWing = useRef<THREE.Group>(null)
  const rightWing = useRef<THREE.Group>(null)
  const target = useMemo(() => new THREE.Vector3(), [])

  useFrame(({ clock }, delta) => {
    const t = clock.elapsedTime
    const g = root.current
    if (!g) return
    const flutterBurst = Math.sin(t * 0.8) > 0.75
    if (perched) {
      const hop = flutterBurst ? Math.abs(Math.sin(t * 9)) * 0.06 + 0.04 : 0
      target
        .set(shoulder[0], shoulder[1] + avatarFloat(t) + hop, shoulder[2])
        .applyAxisAngle(Y_AXIS, Math.sin(t * 0.3) * 0.22)
      g.rotation.y = THREE.MathUtils.damp(g.rotation.y, 0.5 + Math.sin(t * 0.6) * 0.4, 3, delta)
    } else {
      target.set(Math.cos(t * 0.6) * 1.4, 3.4 + Math.sin(t * 1.4) * 0.25, Math.sin(t * 0.6) * 1.1)
      g.rotation.y = -t * 0.6 + Math.PI
    }
    g.position.x = THREE.MathUtils.damp(g.position.x, target.x, 5, delta)
    g.position.y = THREE.MathUtils.damp(g.position.y, target.y, 6, delta)
    g.position.z = THREE.MathUtils.damp(g.position.z, target.z, 5, delta)
    const flapping = !perched || flutterBurst
    const amp = flapping ? 0.9 : 0.06
    const speed = flapping ? 22 : 3
    const w = Math.sin(t * speed) * amp
    if (leftWing.current) leftWing.current.rotation.z = -(perched && !flapping ? 0.05 : 0.3) - w
    if (rightWing.current) rightWing.current.rotation.z = (perched && !flapping ? 0.05 : 0.3) + w
  })

  return (
    <group ref={root} position={shoulder} scale={0.85}>
      <group>
        <mesh scale={[0.75, 0.8, 1.15]} castShadow>
          <sphereGeometry args={[0.1, 24, 20]} />
          <meshPhysicalMaterial color="#060608" roughness={0.3} clearcoat={1} sheen={1} sheenColor="#1d3a7a" />
        </mesh>
        <mesh position={[0, -0.03, 0.035]} scale={[0.62, 0.6, 0.85]}>
          <sphereGeometry args={[0.1, 20, 16]} />
          <meshStandardMaterial color="#f2f0ea" roughness={0.6} />
        </mesh>
        <group position={[0, 0.09, 0.08]}>
          <mesh>
            <sphereGeometry args={[0.065, 20, 16]} />
            <meshPhysicalMaterial color="#060608" roughness={0.3} clearcoat={1} sheen={1} sheenColor="#1d3a7a" />
          </mesh>
          <mesh position={[0, -0.005, 0.08]} rotation={[Math.PI / 2, 0, 0]}>
            <coneGeometry args={[0.016, 0.07, 10]} />
            <meshStandardMaterial color="#1a1a1a" roughness={0.3} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.035, 0.015, 0.05]}>
              <sphereGeometry args={[0.009, 10, 10]} />
              <meshStandardMaterial color="#ff2a2a" emissive="#ff2a2a" emissiveIntensity={2} toneMapped={false} />
            </mesh>
          ))}
          {/* mini top hat */}
          <group position={[0.01, 0.06, -0.005]} rotation={[0, 0, -0.18]}>
            <mesh>
              <cylinderGeometry args={[0.055, 0.055, 0.008, 24]} />
              <meshPhysicalMaterial color="#0c0c0e" roughness={0.4} clearcoat={0.6} />
            </mesh>
            <mesh position={[0, 0.045, 0]}>
              <cylinderGeometry args={[0.033, 0.036, 0.085, 24]} />
              <meshPhysicalMaterial color="#0c0c0e" roughness={0.4} clearcoat={0.6} />
            </mesh>
            <mesh position={[0, 0.014, 0]}>
              <cylinderGeometry args={[0.0365, 0.0365, 0.014, 24]} />
              <meshStandardMaterial color="#b0122a" emissive="#5a0010" roughness={0.5} />
            </mesh>
          </group>
        </group>
        {/* wings with white patches */}
        {[-1, 1].map((s) => (
          <group key={s} ref={s === -1 ? leftWing : rightWing} position={[s * 0.06, 0.03, 0]}>
            <mesh position={[s * 0.07, 0, -0.02]} scale={[1, 0.25, 1.4]}>
              <sphereGeometry args={[0.07, 16, 12]} />
              <meshPhysicalMaterial color="#08080c" roughness={0.3} sheen={1} sheenColor="#2a4fb0" />
            </mesh>
            <mesh position={[s * 0.06, 0.012, 0.0]} scale={[0.7, 0.2, 0.7]}>
              <sphereGeometry args={[0.05, 12, 10]} />
              <meshStandardMaterial color="#f5f3ee" />
            </mesh>
          </group>
        ))}
        <mesh position={[0, 0.0, -0.2]} rotation={[0.35, 0, 0]} scale={[1, 0.15, 1]}>
          <boxGeometry args={[0.06, 0.06, 0.24]} />
          <meshPhysicalMaterial color="#0a0f1e" roughness={0.25} sheen={1} sheenColor="#2bd4a8" clearcoat={1} />
        </mesh>
        {[-1, 1].map((s) => (
          <mesh key={`leg${s}`} position={[s * 0.03, -0.1, 0.01]}>
            <cylinderGeometry args={[0.005, 0.005, 0.06, 6]} />
            <meshStandardMaterial color="#222" />
          </mesh>
        ))}
      </group>
    </group>
  )
}

/* ---------------- Black cat ---------------- */

export function BlackCat({ active, posRef }: { active: boolean; posRef: MutableRefObject<THREE.Vector3> }) {
  const root = useRef<THREE.Group>(null)
  const legs = useRef<(THREE.Group | null)[]>([])
  const tailRef = useRef<THREE.Group>(null)
  const head = useRef<THREE.Group>(null)
  const startAngle = useRef(0)
  const catMat = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: '#070608',
        roughness: 0.42,
        sheen: 1,
        sheenColor: new THREE.Color('#4a3a52'),
        sheenRoughness: 0.4,
        clearcoat: 0.25,
      }),
    [],
  )
  const tail = useMemo(
    () =>
      makeTaperedTube(
        [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0.15, -0.15),
          new THREE.Vector3(0, 0.42, -0.2),
          new THREE.Vector3(0.05, 0.62, -0.1),
          new THREE.Vector3(0.12, 0.7, 0.0),
        ],
        0.035,
        0.5,
      ).geometry,
    [],
  )

  useEffect(() => {
    if (active) startAngle.current = performance.now() / 1000
  }, [active])

  useFrame(({ clock }, delta) => {
    const g = root.current
    if (!g) return
    const t = clock.elapsedTime
    const s = THREE.MathUtils.damp(g.scale.x, active ? 1.5 : 0, active ? 3 : 10, delta)
    g.scale.setScalar(s)
    g.visible = s > 0.01
    if (!g.visible) return
    const walkT = performance.now() / 1000 - startAngle.current
    const a = Math.PI / 2 + walkT * 0.42
    const R = 2.3
    g.position.set(Math.cos(a) * R, 0, Math.sin(a) * R * 0.7)
    const dir = new THREE.Vector3(-Math.sin(a), 0, Math.cos(a) * 0.7)
    g.rotation.y = Math.atan2(dir.x, dir.z)
    posRef.current.set(g.position.x, 0.6, g.position.z)
    legs.current.forEach((leg, i) => {
      if (!leg) return
      const phase = i === 0 || i === 3 ? 0 : Math.PI
      leg.rotation.x = Math.sin(t * 7 + phase) * 0.5
    })
    if (tailRef.current) tailRef.current.rotation.z = Math.sin(t * 2) * 0.3
    if (head.current) head.current.rotation.y = Math.sin(t * 0.7) * 0.25
  })

  const legPositions: [number, number, number][] = [
    [-0.09, 0.34, 0.24],
    [0.09, 0.34, 0.24],
    [-0.09, 0.34, -0.24],
    [0.09, 0.34, -0.24],
  ]

  return (
    <group ref={root} scale={0} visible={false}>
      <mesh material={catMat} position={[0, 0.42, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[1, 1, 0.95]} castShadow>
        <capsuleGeometry args={[0.15, 0.42, 12, 24]} />
      </mesh>
      <group ref={head} position={[0, 0.6, 0.38]}>
        <mesh material={catMat} scale={[1.05, 0.92, 1]} castShadow>
          <sphereGeometry args={[0.135, 32, 24]} />
        </mesh>
        <mesh material={catMat} position={[0, -0.04, 0.1]} scale={[0.9, 0.6, 0.7]}>
          <sphereGeometry args={[0.07, 20, 16]} />
        </mesh>
        {[-1, 1].map((s) => (
          <group key={s}>
            <mesh material={catMat} position={[s * 0.075, 0.13, -0.01]} rotation={[0, 0, s * -0.25]} scale={[1, 1, 0.45]}>
              <coneGeometry args={[0.05, 0.12, 12]} />
            </mesh>
            <mesh position={[s * 0.05, 0.02, 0.115]} scale={[1, 0.75, 0.5]}>
              <sphereGeometry args={[0.022, 16, 12]} />
              <meshStandardMaterial color="#c8ff4a" emissive="#9dff1a" emissiveIntensity={3} toneMapped={false} />
            </mesh>
            <mesh position={[s * 0.05, 0.02, 0.124]} scale={[0.25, 0.8, 0.3]}>
              <sphereGeometry args={[0.018, 10, 10]} />
              <meshBasicMaterial color="#000" />
            </mesh>
          </group>
        ))}
        <mesh position={[0, -0.02, 0.165]}>
          <sphereGeometry args={[0.012, 10, 10]} />
          <meshStandardMaterial color="#2a1a20" />
        </mesh>
      </group>
      {legPositions.map((p, i) => (
        <group
          key={i}
          position={p}
          ref={(el) => {
            legs.current[i] = el
          }}
        >
          <mesh material={catMat} position={[0, -0.16, 0]}>
            <capsuleGeometry args={[0.042, 0.26, 8, 12]} />
          </mesh>
        </group>
      ))}
      <group ref={tailRef} position={[0, 0.48, -0.36]}>
        <mesh geometry={tail} material={catMat} />
      </group>
    </group>
  )
}

/* ---------------- Flying creatures ---------------- */

const BIRD_PALETTES = {
  glowbird: { body: '#fff3c4', wing: '#ffd36a', head: '#fff8e0', glow: '#ffbf3a', emissive: 2.5 },
  parrot: { body: '#18b04a', wing: '#2f6bff', head: '#e23b2e', glow: '#2fff8a', emissive: 0.2 },
} as const

export function FlyingCreature({
  kind,
  posRef,
}: {
  kind: CreatureKind | null
  posRef: MutableRefObject<THREE.Vector3>
}) {
  const root = useRef<THREE.Group>(null)
  const wingsRef = useRef<THREE.Group>(null)
  const prev = useMemo(() => new THREE.Vector3(), [])
  const [shown, setShown] = useState<CreatureKind | null>(kind)
  if (kind && kind !== shown) setShown(kind)

  useFrame(({ clock }, delta) => {
    const g = root.current
    if (!g) return
    const t = clock.elapsedTime
    const s = THREE.MathUtils.damp(g.scale.x, kind ? 2.4 : 0, kind ? 3 : 10, delta)
    g.scale.setScalar(s)
    g.visible = s > 0.01
    prev.copy(g.position)
    g.position.set(Math.sin(t * 0.45) * 3.4, 2.4 + Math.sin(t * 0.9) * 0.7, Math.cos(t * 0.32) * 1.6)
    posRef.current.copy(g.position)
    const dir = g.position.clone().sub(prev)
    if (dir.lengthSq() > 1e-7) {
      g.rotation.y = Math.atan2(dir.x, dir.z)
      g.rotation.z = THREE.MathUtils.clamp(-dir.x * 4, -0.4, 0.4)
    }
    const wings = wingsRef.current
    if (wings) {
      const speed = shown === 'butterfly' ? 16 : shown === 'bat' ? 12 : 14
      const flap = Math.sin(t * speed)
      wings.children.forEach((w, i) => {
        const side = i % 2 === 0 ? 1 : -1
        w.rotation.z = side * (shown === 'butterfly' ? 0.2 + flap * 0.9 : flap * 0.75)
      })
    }
  })

  return (
    <group ref={root} scale={0} visible={false}>
      {shown === 'butterfly' && <ButterflyModel wingsRef={wingsRef} />}
      {shown === 'bat' && <BatModel wingsRef={wingsRef} />}
      {(shown === 'glowbird' || shown === 'parrot') && <BirdModel wingsRef={wingsRef} kind={shown} />}
      {shown && <Whisper kind={shown} />}
    </group>
  )
}

function Whisper({ kind }: { kind: CreatureKind }) {
  const [index, setIndex] = useState(0)
  useEffect(() => {
    const id = window.setInterval(() => setIndex((i) => i + 1), 2600)
    return () => window.clearInterval(id)
  }, [])
  const lines = CREATURE_WHISPERS[kind]
  return (
    <Html position={[0, 0.55, 0]} center distanceFactor={7} zIndexRange={[10, 0]}>
      <p key={index} className="whisper pointer-events-none whitespace-nowrap font-serif text-sm italic text-amber-100/90">
        {lines[index % lines.length]}
      </p>
    </Html>
  )
}

function ButterflyModel({ wingsRef }: { wingsRef: MutableRefObject<THREE.Group | null> }) {
  const shapes = useMemo(() => {
    const upper = new THREE.Shape()
    upper.moveTo(0, 0)
    upper.bezierCurveTo(0.15, 0.35, 0.55, 0.45, 0.5, 0.12)
    upper.bezierCurveTo(0.48, 0.0, 0.2, -0.02, 0, 0)
    const lower = new THREE.Shape()
    lower.moveTo(0, 0)
    lower.bezierCurveTo(0.3, -0.05, 0.42, -0.3, 0.22, -0.38)
    lower.bezierCurveTo(0.1, -0.4, 0.04, -0.2, 0, 0)
    return { upper, lower }
  }, [])
  return (
    <group scale={1.5}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <capsuleGeometry args={[0.025, 0.22, 6, 12]} />
        <meshStandardMaterial color="#120a18" />
      </mesh>
      <group ref={wingsRef}>
        {[1, -1].map((s) => (
          <group key={s} scale={[s, 1, 1]}>
            <group rotation={[Math.PI / 2, 0, 0]}>
            <mesh>
              <shapeGeometry args={[shapes.upper, 20]} />
              <meshStandardMaterial color="#19e3ff" emissive="#00b3ff" emissiveIntensity={1.6} side={THREE.DoubleSide} toneMapped={false} />
            </mesh>
            <mesh position={[0, 0, 0.002]}>
              <shapeGeometry args={[shapes.lower, 20]} />
              <meshStandardMaterial color="#ff3df5" emissive="#c21aff" emissiveIntensity={1.6} side={THREE.DoubleSide} toneMapped={false} />
            </mesh>
            </group>
          </group>
        ))}
      </group>
      <Sparkles count={30} scale={[1, 1, 1]} size={2.5} speed={0.6} color="#7fe9ff" />
    </group>
  )
}

function BatModel({ wingsRef }: { wingsRef: MutableRefObject<THREE.Group | null> }) {
  const shape = useMemo(() => makeBatWingShape(), [])
  return (
    <group>
      <mesh scale={[0.8, 0.8, 1.2]}>
        <sphereGeometry args={[0.1, 20, 16]} />
        <meshPhysicalMaterial color="#120c10" roughness={0.6} sheen={1} sheenColor="#4a2030" />
      </mesh>
      <mesh position={[0, 0.03, 0.12]}>
        <sphereGeometry args={[0.065, 16, 12]} />
        <meshPhysicalMaterial color="#120c10" roughness={0.6} />
      </mesh>
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 0.035, 0.1, 0.11]} rotation={[0, 0, s * -0.3]} scale={[1, 1, 0.5]}>
            <coneGeometry args={[0.025, 0.08, 8]} />
            <meshStandardMaterial color="#120c10" />
          </mesh>
          <mesh position={[s * 0.025, 0.04, 0.175]}>
            <sphereGeometry args={[0.01, 8, 8]} />
            <meshStandardMaterial color="#ff1a1a" emissive="#ff1a1a" emissiveIntensity={4} toneMapped={false} />
          </mesh>
        </group>
      ))}
      <group ref={wingsRef}>
        {[1, -1].map((s) => (
          <group key={s} scale={[s * 0.35, 0.35, 0.35]}>
            <group rotation={[Math.PI / 2, 0, 0]}>
            <mesh>
              <shapeGeometry args={[shape, 16]} />
              <meshPhysicalMaterial color="#1a0d14" emissive="#5a0a1a" emissiveIntensity={0.4} side={THREE.DoubleSide} roughness={0.7} />
            </mesh>
            {BAT_WING_BONES.map(([a, b], i) => {
              const seg = segmentTransform(a, b)
              return (
                <mesh key={i} position={seg.position} quaternion={seg.quaternion}>
                  <cylinderGeometry args={[0.02, 0.025, seg.length, 6]} />
                  <meshStandardMaterial color="#0a0508" />
                </mesh>
              )
            })}
            </group>
          </group>
        ))}
      </group>
    </group>
  )
}

function BirdModel({
  wingsRef,
  kind,
}: {
  wingsRef: MutableRefObject<THREE.Group | null>
  kind: 'glowbird' | 'parrot'
}) {
  const p = BIRD_PALETTES[kind]
  const wingShape = useMemo(() => {
    const s = new THREE.Shape()
    s.moveTo(0, 0.06)
    s.quadraticCurveTo(0.25, 0.12, 0.5, 0.02)
    s.lineTo(0.42, -0.04)
    s.lineTo(0.3, -0.08)
    s.lineTo(0.15, -0.1)
    s.lineTo(0, -0.06)
    return s
  }, [])
  const glow = kind === 'glowbird'
  return (
    <group>
      <mesh scale={[0.7, 0.7, 1.3]}>
        <sphereGeometry args={[0.1, 20, 16]} />
        <meshStandardMaterial color={p.body} emissive={p.glow} emissiveIntensity={p.emissive} toneMapped={!glow} />
      </mesh>
      <mesh position={[0, 0.05, 0.12]}>
        <sphereGeometry args={[0.06, 16, 12]} />
        <meshStandardMaterial color={p.head} emissive={p.glow} emissiveIntensity={p.emissive} toneMapped={!glow} />
      </mesh>
      <mesh position={[0, 0.03, 0.19]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.02, 0.06, 8]} />
        <meshStandardMaterial color={kind === 'parrot' ? '#ffd21a' : '#ffffff'} />
      </mesh>
      <mesh position={[0, 0, -0.2]} rotation={[0.2, 0, 0]} scale={[1, 0.2, 1]}>
        <boxGeometry args={[0.08, 0.08, 0.22]} />
        <meshStandardMaterial color={kind === 'parrot' ? '#ff3b2e' : p.wing} emissive={p.glow} emissiveIntensity={p.emissive} toneMapped={!glow} />
      </mesh>
      <group ref={wingsRef}>
        {[1, -1].map((s) => (
          <group key={s} scale={[s, 1, 1]} position={[s * 0.04, 0.03, 0]}>
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <shapeGeometry args={[wingShape, 12]} />
              <meshStandardMaterial color={p.wing} emissive={p.glow} emissiveIntensity={p.emissive} side={THREE.DoubleSide} toneMapped={!glow} />
            </mesh>
          </group>
        ))}
      </group>
      {glow && (
        <>
          <Sparkles count={40} scale={[1.2, 1.2, 1.2]} size={3} speed={0.8} color="#ffd36a" />
          <pointLight color="#ffcf6a" intensity={3} distance={3} />
        </>
      )}
    </group>
  )
}
