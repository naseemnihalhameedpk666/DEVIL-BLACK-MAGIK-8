import { DevilDashboard } from '@/components/devil/dashboard'

export default function Page() {
  return <DevilDashboard />
}
