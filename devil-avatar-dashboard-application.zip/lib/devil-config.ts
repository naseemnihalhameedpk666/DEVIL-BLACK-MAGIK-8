export type Gender = 'male' | 'female'
export type HornStyle = 'curved' | 'straight' | 'ram'
export type BodyBuild = 'lean' | 'strong' | 'titan'
export type EyebrowStyle = 'fierce' | 'arched' | 'heavy' | 'none'
export type Markings = 'none' | 'scars' | 'runes'
export type EyeLensId = 'fire' | 'ice' | 'gold' | 'void'
export type Alignment = 'devil' | 'angel'
export type CameraMode = 'face' | 'body'
export type Form = 'devil' | 'cat' | 'creature'
export type CreatureKind = 'butterfly' | 'bat' | 'glowbird' | 'parrot'
export type ActionKind = 'eyes' | 'hands' | 'both'

export interface AvatarConfig {
  gender: Gender
  wings: string
  skin: string
  eyes: EyeLensId
  horns: HornStyle
  build: BodyBuild
  eyebrows: EyebrowStyle
  markings: Markings
}

export interface Profile {
  id: string
  name: string
  alignment: Alignment
  locked: boolean
  config: AvatarConfig
}

export const MAX_PROFILES = 18
export const SHAPESHIFT_INTERVAL_MS = 120_000
export const CAT_DURATION_MS = 16_000
export const ACTION_DURATION_MS = 2_800

export const WING_COLORS = [
  { id: 'obsidian', label: 'Black', color: '#0e0b10', glow: '#6a1424' },
  { id: 'crimson', label: 'Crimson', color: '#6e0914', glow: '#ff2a3d' },
  { id: 'gold', label: 'Gold', color: '#8a6416', glow: '#ffc94d' },
  { id: 'teal', label: 'Dark Teal', color: '#0b3a3d', glow: '#2de0d0' },
  { id: 'bone', label: 'White / Bone', color: '#cfc4b0', glow: '#fff1d6' },
  { id: 'violet', label: 'Abyss Violet', color: '#230c34', glow: '#b04dff' },
] as const

export const SKIN_TONES = [
  { id: 'red', label: 'Red', color: '#9a1a1c' },
  { id: 'crimson', label: 'Crimson', color: '#661020' },
  { id: 'tan', label: 'Tan', color: '#a6744e' },
  { id: 'gray', label: 'Dark Gray', color: '#3a3a40' },
  { id: 'copper', label: 'Copper', color: '#a3552a' },
  { id: 'blueblack', label: 'Blue-Black', color: '#161b2c' },
] as const

export const EYE_LENSES: Record<
  EyeLensId,
  { label: string; iris: string; glow: string; sclera: string }
> = {
  fire: { label: 'Fire', iris: '#ff6a1a', glow: '#ff3a00', sclera: '#2a0800' },
  ice: { label: 'Ice Blue', iris: '#9ff0ff', glow: '#33c8ff', sclera: '#04121c' },
  gold: { label: 'Gold', iris: '#ffd86a', glow: '#ffb300', sclera: '#1c1200' },
  void: { label: 'Void', iris: '#ff0022', glow: '#ff0022', sclera: '#000000' },
}

export const BUILD_SCALE: Record<BodyBuild, [number, number, number]> = {
  lean: [0.9, 1, 0.9],
  strong: [1.05, 1, 1.05],
  titan: [1.28, 1.07, 1.2],
}

export const OPTION_LABELS = {
  gender: { male: 'Male Devil', female: 'Female Devil' },
  horns: { curved: 'Curved', straight: 'Straight', ram: 'Ram' },
  build: { lean: 'Lean', strong: 'Strong', titan: 'Titan' },
  eyebrows: { fierce: 'Fierce', arched: 'Arched', heavy: 'Heavy', none: 'None' },
  markings: { none: 'None', scars: 'Face Scars', runes: 'Ancient Runes' },
} as const

export const DEFAULT_CONFIG: AvatarConfig = {
  gender: 'male',
  wings: 'obsidian',
  skin: 'red',
  eyes: 'fire',
  horns: 'curved',
  build: 'strong',
  eyebrows: 'fierce',
  markings: 'runes',
}

export interface AngelNumber {
  value: string
  title: string
  meaning: string
  effect:
    | { type: 'creature'; creature: CreatureKind }
    | { type: 'action'; action: ActionKind }
}

export const ANGEL_NUMBERS: AngelNumber[] = [
  { value: '111', title: 'Glowing Bird', meaning: 'Manifestation gate', effect: { type: 'creature', creature: 'glowbird' } },
  { value: '222', title: 'Parrot', meaning: 'Harmony & echoes', effect: { type: 'creature', creature: 'parrot' } },
  { value: '369', title: 'Eye Fire Blast', meaning: 'Tesla key of the universe', effect: { type: 'action', action: 'eyes' } },
  { value: '555', title: 'Vivid Butterfly', meaning: 'Metamorphosis', effect: { type: 'creature', creature: 'butterfly' } },
  { value: '666', title: 'Night Bat', meaning: 'Shadow sovereignty', effect: { type: 'creature', creature: 'bat' } },
  { value: '731', title: 'Hand Hellfire', meaning: 'Forged will', effect: { type: 'action', action: 'hands' } },
  { value: '952', title: 'Infernal Overload', meaning: 'Total ignition', effect: { type: 'action', action: 'both' } },
]

export const CREATURE_WHISPERS: Record<CreatureKind, string[]> = {
  butterfly: ['change is coming…', 'shed the old skin…', 'become…'],
  bat: ['the night listens…', 'we see in the dark…', 'hunger…'],
  glowbird: ['light finds you…', 'rise, little flame…', 'begin again…'],
  parrot: ['repeat after me…', 'secrets, secrets…', 'they are watching…'],
}

export const CREATURE_LABELS: Record<CreatureKind, string> = {
  butterfly: 'Vivid Butterfly',
  bat: 'Night Bat',
  glowbird: 'Glowing Bird',
  parrot: 'Parrot',
}

export interface Chakra {
  id: string
  name: string
  sanskrit: string
  color: string
  hz: number
  minutes: number
  y: number
  ringRadius: number
}

export const CHAKRAS: Chakra[] = [
  { id: 'soulstar', name: 'Soul Star', sanskrit: 'Sutara', color: '#f4ecff', hz: 1074, minutes: 3, y: 3.82, ringRadius: 0.26 },
  { id: 'crown', name: 'Crown', sanskrit: 'Sahasrara', color: '#b57bff', hz: 963, minutes: 5, y: 3.38, ringRadius: 0.3 },
  { id: 'thirdeye', name: 'Third Eye', sanskrit: 'Ajna', color: '#6a6aff', hz: 852, minutes: 5, y: 3.12, ringRadius: 0.32 },
  { id: 'throat', name: 'Throat', sanskrit: 'Vishuddha', color: '#3fb6ff', hz: 741, minutes: 4, y: 2.78, ringRadius: 0.2 },
  { id: 'heart', name: 'Heart', sanskrit: 'Anahata', color: '#3ddc84', hz: 639, minutes: 6, y: 2.34, ringRadius: 0.62 },
  { id: 'solar', name: 'Solar Plexus', sanskrit: 'Manipura', color: '#ffd23f', hz: 528, minutes: 5, y: 2.02, ringRadius: 0.5 },
  { id: 'sacral', name: 'Sacral', sanskrit: 'Svadhisthana', color: '#ff8a1f', hz: 417, minutes: 4, y: 1.78, ringRadius: 0.52 },
  { id: 'root', name: 'Root', sanskrit: 'Muladhara', color: '#ff2d2d', hz: 396, minutes: 7, y: 1.55, ringRadius: 0.55 },
]

export function wingById(id: string) {
  return WING_COLORS.find((w) => w.id === id) ?? WING_COLORS[0]
}

export function skinById(id: string) {
  return SKIN_TONES.find((s) => s.id === id) ?? SKIN_TONES[0]
}
